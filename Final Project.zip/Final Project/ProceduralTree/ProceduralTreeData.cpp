#include "ProceduralTreeData.h"
#include <glm/gtc/constants.hpp>

using namespace std;
using namespace glm;
float curveLength(const vector<vec3> &curve);

float randomUniform01()
{
	const double recp = 1.0 / RAND_MAX;
	return (rand() % RAND_MAX)*recp;
}

float randomExp(float k)
{
	float x = randomUniform01();
	if (x == 0.0)
	{
		x = 1e-6;
	}
	return -log(x)*k;
}

int ProceduralTreeData::Seed() { return mainRandomSeed; }

const Mesh & ProceduralTreeData::getMesh() const
{
	return mesh;
}

ProceduralTreeData::ProceduralTreeData()
{
	mainRandomSeed = rand();
	srand(mainRandomSeed);
	for (auto& sd:subRandomSeed)
	{
		sd = rand();
	}
}

ProceduralTreeData::~ProceduralTreeData()
{
	for (auto &listerner:dataChangeListeners)
	{
		listerner->onRemoveFromTree(this);
	}
}

void ProceduralTreeData::newSeed()
{
	mainRandomSeed = mainRandomSeed+1;
	srand(mainRandomSeed);
	for (auto& sd : subRandomSeed)
	{
		sd = rand();
	}
	GenerateMesh();
}

void ProceduralTreeData::GenerateMesh()
{
	for (auto &listener:dataChangeListeners)
	{
		listener->onTreeDataChanged(this);
	}
	if (child)
	{
		child->GenerateMesh();
	}
}

void ProceduralTreeData::addDataChangeListener(ProceduralTreeDataListener * listerner)
{
	auto iter = find(dataChangeListeners.begin(), dataChangeListeners.end(), listerner);
	if (iter == dataChangeListeners.end())
	{
		dataChangeListeners.push_back(listerner);
	}
	GenerateMesh();
}

void ProceduralTreeData::removeDataChangeListener(ProceduralTreeDataListener * listerner)
{
	auto iter = find(dataChangeListeners.begin(), dataChangeListeners.end(), listerner);
	if (iter!= dataChangeListeners.end())
	{
		dataChangeListeners.erase(iter);
	}
}

void ProceduralTreeData::setChildData(std::shared_ptr<ProceduralTreeData> newChild)
{
	child = newChild;
	if (child)
	{
		child->parent = shared_from_this();
	}
}

std::shared_ptr<ProceduralTreeData> ProceduralTreeData::Child()
{
	return child;
}

void ProceduralTreeData::generateMeshFromCurve(const std::vector<glm::vec3> &curve, int radialSegments, const std::vector<glm::vec2>& radiusCurve, float radiusNoise,
	std::vector<glm::vec3> &positions, std::vector<glm::vec3> &normals, std::vector<glm::vec2> &uvs, std::vector<unsigned int> &indices)
{
	auto &radialCurveSamples = radiusCurve;

	vec3 lastN = vec3(1, 0, 0), lastBT = vec3(0, 0, 1);

	unsigned int baseVertexIndex = positions.size();

	vector<vec3> tmpPositions;
	float curveLen = curveLength(curve);
	float curLen = 0;
	float UScale = 2, VScale = 0.2;
	for (size_t i = 0; i < curve.size(); i++)
	{
		auto i1 = clamp<int>(i - 1, 0, curve.size() - 1);
		auto i2 = clamp<int>(i + 1, 0, curve.size() - 1);

		vec3 BT, N;
		vec3 t = normalize(curve[i2] - curve[i1]);
		if (glm::length(cross(t, lastN))<1e-6)
		{
			N = normalize(cross(t, lastBT));
			BT = normalize(cross(N, t));
		}
		else
		{
			BT = normalize(cross(lastN, t));
			N = normalize(cross(t, BT));
		}

		lastN = N, lastBT = BT;

		float radius = Simple2DCurve::evaluate(radialCurveSamples, curLen / curveLen);
		for (size_t j = 0; j < radialSegments; j++)
		{
			float sa = glm::sin(float(j) / radialSegments * 2 * glm::pi<float>());
			float ca = glm::cos(float(j) / radialSegments * 2 * glm::pi<float>());
			float noiseScale = (1 + radiusNoise*(randomUniform01() - 0.5f) * 2.0f);
			float R = radius*noiseScale;
			tmpPositions.push_back((N*ca + BT*sa)*R + curve[i]);
			uvs.push_back({ UScale*j / (radialSegments),VScale*(i) });
		}
		tmpPositions.push_back(*(tmpPositions.end() - radialSegments));
		uvs.push_back({ UScale,VScale*(i) });

		if (i<curve.size() - 1)
		{
			curLen += length(curve[i + 1] - curve[i]);
		}
	}

	int loopVertexCount = radialSegments + 1;
	for (size_t i = 0; i < curve.size(); i++)
	{
		for (size_t j = 0; j < radialSegments; j++)
		{
			int t = clamp<int>(i + 1, 0, curve.size() - 1);
			int b = clamp<int>(i - 1, 0, curve.size() - 1);

			int l = (j - 1 + radialSegments) % radialSegments;
			int r = (j + 1 + radialSegments) % radialSegments;

			vec3 v1 = tmpPositions[t*loopVertexCount + j] - tmpPositions[b*loopVertexCount + j];
			vec3 v2 = tmpPositions[i*loopVertexCount + r] - tmpPositions[i*loopVertexCount + l];
			if (length(cross(v1, v2)) < 1e-6)
			{
				normals.push_back({0, 1, 0});
			}
			else
			{
				normals.push_back(normalize(cross(v1, v2)));
			}
		}
		normals.push_back(*(normals.end() - radialSegments));
	}
	positions.insert(positions.end(), tmpPositions.begin(), tmpPositions.end());


	for (size_t i = 0; i < curve.size()-1; i++)
	{
		for (size_t j = 0; j < radialSegments; j++)
		{
			indices.push_back(baseVertexIndex + j + (i)*loopVertexCount);
			indices.push_back(baseVertexIndex + j + 1 + (i)*loopVertexCount);
			indices.push_back(baseVertexIndex + j + 1 + (i+1)*loopVertexCount);
			indices.push_back(baseVertexIndex + j + (i)*loopVertexCount);
			indices.push_back(baseVertexIndex + j + 1 + (i + 1)*loopVertexCount);
			indices.push_back(baseVertexIndex + j + (i + 1)*loopVertexCount);
		}
	}
}

Trunk::Trunk()
{
	spine.insertControlPoint(0, {
		{ 0,0,0 },
		{ 0,1,0 },
		1,
		5,
	});

	spine.insertControlPoint(1, {
		{ 0,10,0 },
		{ 0,1,0 },
		5,
		1,
	});

	trunkRadiusCurve.knots = {
		{ 0,1 },
		{ 0.2,0.9 },
		{ 0.4,0.8 },
		{ 0.6,0.7 },
		{ 0.8,0.6 },
		{1,0.5},
	};
	spine.addListener(this);
}

float curveLength(const vector<vec3> &curve)
{
	float len = 0;
	for (int i=0;i<curve.size()-1;++i)
	{
		len += length(curve[i+1] - curve[i]);
	}
	return len;
}

std::vector<glm::vec3> ProceduralTreeData::getNoisedCurve(const std::vector<glm::vec3>& curve, float noiseAmount, float noiseScale)
{
	float curveLen = curveLength(curve);
	Simple2DCurve noiseOffsetAmountCurve;
	Simple2DCurve noiseOffsetAngleCurve;
	for (float l = 0; l < curveLen + noiseScale; l += noiseScale)
	{
		noiseOffsetAmountCurve.knots.push_back({ l,randomUniform01() });
		noiseOffsetAngleCurve.knots.push_back({ l,randomUniform01() * 2 * pi<float>() });
	}

	auto noiseOffsetAmountSamples = noiseOffsetAmountCurve.sampleCurve(20 * noiseOffsetAmountCurve.knots.size());
	auto noiseOffsetAngleSamples = noiseOffsetAngleCurve.sampleCurve(20 * noiseOffsetAngleCurve.knots.size());

	//apply noise to spine
	vec3 lastN = vec3(1, 0, 0), lastBT = vec3(0, 0, 1);

	auto newCurve = curve;
	float spineLen = 0;
	for (size_t i = 0; i < curve.size(); i++)
	{
		auto i1 = clamp<int>(i - 1, 0, curve.size() - 1);
		auto i2 = clamp<int>(i + 1, 0, curve.size() - 1);

		vec3 BT, N;
		vec3 t = normalize(curve[i2] - curve[i1]);
		if (glm::length(cross(t, lastN))<1e-6)
		{
			N = normalize(cross(t, lastBT));
			BT = normalize(cross(N, t));
		}
		else
		{
			BT = normalize(cross(lastN, t));
			N = normalize(cross(t, BT));
		}

		lastN = N, lastBT = BT;

		float offsetAngle = Simple2DCurve::evaluate(noiseOffsetAngleSamples, spineLen);
		float offsetAmount = Simple2DCurve::evaluate(noiseOffsetAmountSamples, spineLen);
		if (i< curve.size() - 1)
		{
			spineLen += glm::length(curve[i + 1] - curve[i]);
		}


		float soa = sin(offsetAngle), coa = cos(offsetAngle);
		vec3 offset = (soa*N + coa*BT)*noiseAmount*offsetAmount;
		newCurve[i] += offset;
	}

	return newCurve;
}

void Trunk::GenerateMesh()
{
	auto curve = getNoisedTrunkSpine();

	srand(mainRandomSeed);

	mesh.normal.clear();
	mesh.position.clear();
	mesh.uv.clear();
	mesh.indices.clear();

	auto radialCurveSamples = trunkRadiusCurve.sampleCurve(curve.size());
	for (auto &rs : radialCurveSamples)
	{
		rs.y *= radius;
	}

	generateMeshFromCurve(curve, radialSegments, radialCurveSamples, barkNoise, mesh.position, mesh.normal, mesh.uv,mesh.indices);

	ProceduralTreeData::GenerateMesh();
}

std::vector<SplitSlot> Trunk::getSplitSlot(int randomSeed, float startPos, float interval)
{
	auto curve = getNoisedTrunkSpine();
	float curveLen = curveLength(curve);
	auto radialCurveSamples = trunkRadiusCurve.sampleCurve(curve.size());
	srand(randomSeed);

	std::vector<SplitSlot> res;

	float curLen = 0;
	float nextLen = startPos*curveLen;

	for(int i = 0;i<curve.size();++i)
	{
		while (curLen>nextLen)
		{
			float segLen= length(curve[i] - curve[i-1]);
			float w = (nextLen - (curLen - segLen)) / segLen;

			SplitSlot slot;
			slot.position = w*curve[i] + (1 - w)*curve[i - 1];
			slot.direction = normalize(curve[i] - curve[i-1]);
			slot.rootRadius = Simple2DCurve::evaluate(radialCurveSamples, nextLen/ curveLen)*radius;
			//nextLen += randomExp(interval);
			nextLen += interval;
			res.push_back(slot);
		}
		if (i<curve.size()-1)
		{
			curLen += length(curve[i + 1] - curve[i]);
		}
	}

	return res;
}

std::vector<glm::vec3> Trunk::getNoisedTrunkSpine()
{
	srand(subRandomSeed[0]);
	return getNoisedCurve(spine.sampleCurve(segments), spineNoise, spineNoiseScale);;
}

void Trunk::onCurveUpdate(BezierCurve * curve)
{
	GenerateMesh();
}

Tree::Tree()
{
}

std::vector<SplitSlot> Branch::getSplitSlot(int randomSeed, float startPos, float interval)
{
	Simple2DCurve radiusCurve;
	radiusCurve.knots.push_back({ 0,1 });
	radiusCurve.knots.push_back({ 1,0 });

	auto radiusCurveSamples = radiusCurve.sampleCurve(segments);
	auto slots = parent.lock()->getSplitSlot(mainRandomSeed, startSplitPos, splitInterval);
	vector<vector<vec3>> spines = getNoisedBranchSpines(slots);

	srand(randomSeed);
	std::vector<SplitSlot> res;

	for (int i=0;i<slots.size();++i)
	{
		auto &curve = spines[i];
		vector<vec2> radiusCurveTmp;
		for (auto &r : radiusCurveSamples)
		{
			radiusCurveTmp.push_back({ r.x,r.y*slots[i].rootRadius*radiusScale });
		}

		float curveLen = curveLength(curve);


		float curLen = 0;
		float nextLen = startPos*curveLen;

		for (int i = 0; i<curve.size(); ++i)
		{
			while (curLen>nextLen)
			{
				float segLen = length(curve[i] - curve[i - 1]);
				float w = (nextLen - (curLen - segLen)) / segLen;

				SplitSlot slot;
				slot.position = w*curve[i] + (1 - w)*curve[i - 1];
				slot.direction = normalize(curve[i] - curve[i - 1]);
				slot.rootRadius = Simple2DCurve::evaluate(radiusCurveTmp, nextLen / curveLen);
				//nextLen += randomExp(interval);
				nextLen += interval;
				res.push_back(slot);
			}
			if (i<curve.size() - 1)
			{
				curLen += length(curve[i + 1] - curve[i]);
			}
		}
	}

	return res;
}

void Branch::GenerateMesh()
{
	if (parent.lock())
	{
		mesh.normal.clear();
		mesh.position.clear();
		mesh.uv.clear();
		mesh.indices.clear();

		Simple2DCurve radiusCurve;
		radiusCurve.knots.push_back({ 0,1 });
		radiusCurve.knots.push_back({ 1,0 });

		auto radiusCurveSamples = radiusCurve.sampleCurve(segments);
		auto slots = parent.lock()->getSplitSlot(mainRandomSeed, startSplitPos, splitInterval);
		vector<vector<vec3>> spines=getNoisedBranchSpines(slots);

		srand(mainRandomSeed);

		for (int i=0;i<slots.size();++i)
		{
			vector<vec2> radiusCurveTmp;
			for (auto &r: radiusCurveSamples)
			{
				radiusCurveTmp.push_back({r.x,r.y*slots[i].rootRadius*radiusScale});
			}
			generateMeshFromCurve(spines[i], radialSegments, radiusCurveTmp, barkNoise, mesh.position, mesh.normal, mesh.uv, mesh.indices);
		}
		ProceduralTreeData::GenerateMesh();
	}

}

std::vector<std::vector<glm::vec3>> Branch::getNoisedBranchSpines(const std::vector<SplitSlot> &slots)
{
	srand(mainRandomSeed);

	vector<vector<vec3>> spines;

	int angleDistribution[4] = { 0 };

	auto findMinDistrution = [&angleDistribution]()->int{
		int minDist = angleDistribution[0];
		int count = 1;
		for (int i=1;i<size(angleDistribution);++i)
		{
			if (angleDistribution[i]<minDist)
			{
				minDist = angleDistribution[i];
				count = 1;
			}
			else if (angleDistribution[i]==minDist)
			{
				count += 1;
			}
		}

		int idx = rand() % count;
		for (int i = 0; i<size(angleDistribution); ++i)
		{
			if (angleDistribution[i] == minDist)
			{
				if (idx==0)
				{
					return i;
				}
				else
				{
					idx -= 1;
				}
			}
		}
	};

	for (auto &slot : slots)
	{
		vector<vec3> spineCurve;
		float totalLen = slot.rootRadius*radiusScale*stretch;

		int angleSeg = findMinDistrution();
		angleDistribution[angleSeg]++;
		float rotA = (angleSeg+randomUniform01())*2 * pi<float>()/size(angleDistribution);
		vec3 N,BT;
		if (length(cross(slot.direction,vec3(0,1,0)))<1e-6)
		{
			N = vec3(1, 0, 0);
			BT = normalize(cross(N, slot.direction));
			N = normalize(cross(slot.direction, BT));
		}
		else
		{
			N = vec3(0, 1, 0);
			BT = normalize(cross(N, slot.direction));
			N = normalize(cross(slot.direction, BT));
		}

		vec3 dir2 = N*sin(rotA) + BT*cos(rotA);

		float sep = seperation + (randomUniform01() * 2 - 1)*0.05;
		float sepAngle = sep*pi<float>()*0.5;
		vec3 dir = slot.direction*cos(sepAngle) + dir2*sin(sepAngle);
		dir = normalize(dir);
		for (size_t i = 0; i < segments; i++)
		{
			float segDis = totalLen / segments;
			if (!i)
			{
				spineCurve.push_back(slot.position);
			}
			else
			{
				float curveture = ((float)i / segments);
				vec3 newDir = normalize(dir - vec3(0, curveture*curveture*gravityScale, 0));
				spineCurve.push_back(*spineCurve.rbegin() + newDir*segDis);
			}
		}

		spines.push_back(spineCurve);
	}

	srand(subRandomSeed[0]);

	for (auto &curve : spines)
	{
		vec3 originalPos = curve[0];
		curve = getNoisedCurve(curve, spineNoise, spineNoiseScale);
		vec3 delta = originalPos - curve[0];
		for (auto &p:curve)
		{
			p += delta;
		}
	}

	return spines;
}

std::vector<std::vector<glm::vec3>> Twig::getTwigSpines(const std::vector<SplitSlot>& slots)
{
	srand(mainRandomSeed);

	vector<vector<vec3>> spines;

	int angleDistribution[4] = { 0 };

	auto findMinDistrution = [&angleDistribution]()->int {
		int minDist = angleDistribution[0];
		int count = 1;
		for (int i = 1; i<size(angleDistribution); ++i)
		{
			if (angleDistribution[i]<minDist)
			{
				minDist = angleDistribution[i];
				count = 1;
			}
			else if (angleDistribution[i] == minDist)
			{
				count += 1;
			}
		}

		int idx = rand() % count;
		for (int i = 0; i<size(angleDistribution); ++i)
		{
			if (angleDistribution[i] == minDist)
			{
				if (idx == 0)
				{
					return i;
				}
				else
				{
					idx -= 1;
				}
			}
		}
	};

	for (auto &slot : slots)
	{
		vector<vec3> spineCurve;
		float totalLen = stretch;

		int angleSeg = findMinDistrution();
		angleDistribution[angleSeg]++;
		float rotA = (angleSeg + randomUniform01()) * 2 * pi<float>() / size(angleDistribution);
		vec3 N, BT;
		if (length(cross(slot.direction, vec3(0, 1, 0)))<1e-6)
		{
			N = vec3(1, 0, 0);
			BT = normalize(cross(N, slot.direction));
			N = normalize(cross(slot.direction, BT));
		}
		else
		{
			N = vec3(0, 1, 0);
			BT = normalize(cross(N, slot.direction));
			N = normalize(cross(slot.direction, BT));
		}

		vec3 dir2 = N*sin(rotA) + BT*cos(rotA);

		float sep = seperation + (randomUniform01() * 2 - 1)*0.05;
		float sepAngle = sep*pi<float>()*0.5;
		vec3 dir = slot.direction*cos(sepAngle) + dir2*sin(sepAngle);
		dir = normalize(dir);
		for (size_t i = 0; i < segments; i++)
		{
			float segDis = totalLen / segments;
			if (!i)
			{
				spineCurve.push_back(slot.position);
			}
			else
			{
				float curveture = ((float)i / segments)*2.0;
				vec3 newDir = normalize(dir - vec3(0, curveture*curveture*gravityScale, 0));
				spineCurve.push_back(*spineCurve.rbegin() + newDir*segDis);
			}
		}

		spines.push_back(spineCurve);
	}

	return spines;
}

void Twig::GenerateMesh()
{
	if (parent.lock())
	{
		mesh.normal.clear();
		mesh.position.clear();
		mesh.uv.clear();
		mesh.indices.clear();

		auto slots = parent.lock()->getSplitSlot(mainRandomSeed, startSplitPos, splitInterval);
		vector<vector<vec3>> spines = getTwigSpines(slots);

		srand(mainRandomSeed);

		for (int i = 0; i<slots.size(); ++i)
		{
			vector<vec2> radiusCurveTmp = {
				{ 0,radius },
				{ 1,radius },
			};
			generateMeshFromCurve(spines[i], radialSegments, radiusCurveTmp, 0, mesh.position, mesh.normal, mesh.uv, mesh.indices);
		}
		ProceduralTreeData::GenerateMesh();
	}
}

std::vector<SplitSlot> Twig::getSplitSlot(int randomSeed, float startPos, float interval)
{
	auto slots = parent.lock()->getSplitSlot(mainRandomSeed, startSplitPos, splitInterval);
	vector<vector<vec3>> spines = getTwigSpines(slots);

	srand(randomSeed);
	std::vector<SplitSlot> res;

	for (int i = 0; i<slots.size(); ++i)
	{
		auto &curve = spines[i];
		float curveLen = curveLength(curve);

		float curLen = 0;
		float nextLen = startPos*curveLen;

		for (int j = 0; j<curve.size(); ++j)
		{
			while (curLen>nextLen)
			{
				float segLen = length(curve[j] - curve[j - 1]);
				float w = (nextLen - (curLen - segLen)) / segLen;

				SplitSlot slot;
				slot.position = w*curve[j] + (1 - w)*curve[j - 1];
				slot.direction = normalize(curve[j] - curve[j - 1]);
				slot.rootRadius = slots[i].rootRadius;
				//nextLen += randomExp(interval);
				nextLen += interval;
				res.push_back(slot);
			}
			if (j<curve.size() - 1)
			{
				curLen += length(curve[j + 1] - curve[j]);
			}
		}
	}

	return res;
}

void Leaf::GenerateMesh()
{
	if (parent.lock())
	{
		mesh.normal.clear();
		mesh.position.clear();
		mesh.uv.clear();
		mesh.indices.clear();

		auto slots = parent.lock()->getSplitSlot(mainRandomSeed, startSplitPos, splitInterval);
		srand(mainRandomSeed);

		for (auto &slot:slots)
		{
			int startIndex = mesh.position.size();

			float rotA = randomUniform01() * 2 * pi<float>();
			vec3 N, BT;
			if (glm::length(cross(slot.direction, vec3(0, 1, 0)))<1e-6)
			{
				N = vec3(1, 0, 0);
				BT = normalize(cross(N, slot.direction));
				N = normalize(cross(slot.direction, BT));
			}
			else
			{
				N = vec3(0, 1, 0);
				BT = normalize(cross(N, slot.direction));
				N = normalize(cross(slot.direction, BT));
			}

			vec3 dir2 = N*sin(rotA) + BT*cos(rotA);

			float sep = seperation + (randomUniform01() * 2 - 1)*0.05;
			float sepAngle = sep*pi<float>()*0.5;
			vec3 dir = slot.direction*cos(sepAngle) + dir2*sin(sepAngle);
			dir = normalize(dir);
			vec3 d1 = normalize(cross(dir, { dir.z,dir.x,dir.y}));
			vec3 d2 = normalize(cross(d1, dir));
			float rotB = randomUniform01() * 2 * pi<float>();
			vec3 d3 = d1*cos(rotB) + d2*sin(rotB);
			vec3 leafN = normalize(cross(dir, d3));

			mesh.position.push_back(slot.position + width*d3*0.5f);
			mesh.position.push_back(slot.position + width*d3*0.5f + length*dir);
			mesh.position.push_back(slot.position - width*d3*0.5f + length*dir);
			mesh.position.push_back(slot.position - width*d3*0.5f);

			mesh.normal.push_back(leafN);
			mesh.normal.push_back(leafN);
			mesh.normal.push_back(leafN);
			mesh.normal.push_back(leafN);

			mesh.uv.push_back({ 0,1 });
			mesh.uv.push_back({ 1,1 });
			mesh.uv.push_back({ 1,0 });
			mesh.uv.push_back({ 0,0 });

			mesh.indices.push_back(startIndex + 0);
			mesh.indices.push_back(startIndex + 1);
			mesh.indices.push_back(startIndex + 2);
			mesh.indices.push_back(startIndex + 0);
			mesh.indices.push_back(startIndex + 2);
			mesh.indices.push_back(startIndex + 3);
		}
		ProceduralTreeData::GenerateMesh();
	}
}

std::vector<SplitSlot> Leaf::getSplitSlot(int randomSeed, float startPos, float interval)
{
	return std::vector<SplitSlot>();
}


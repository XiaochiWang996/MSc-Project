#pragma once
#include <glm/glm.hpp>
#include <vector>
#include <set>
#include <functional>

#include <json.hpp>

class BezierCurve;
class BezierCurveListener
{
public:
	virtual void onCurveUpdate(BezierCurve *curve)=0;
};

class BezierCurve
{
	struct ControlPoint;
	std::vector<ControlPoint> controlPoints;

	void updateCurve();
	std::set<BezierCurveListener *> curveUpdateListeners;

public:
	struct ControlPoint
	{
		glm::vec3 position;
		glm::vec3 tangent;
		float leftHandleDis;
		float rightHandleDis;
	};

	BezierCurve();
	~BezierCurve();

	void addListener(BezierCurveListener *listener);
	void removeListener(BezierCurveListener *listener);
	int controlPointCount();
	ControlPoint getControlPoint(int index);
	void updateControlPoint(int index, const ControlPoint &cp);
	void insertControlPoint(int index, const ControlPoint &cp);
	void deleteControlPoint(int index);
	std::vector<glm::vec3> sampleCurve(int segmentCount);

	void Serialize(nlohmann::json &dict);
	void Deserialize(const nlohmann::json &dict);

};

class Simple2DCurve
{
public:
	std::vector<glm::vec2> knots;
	std::vector<glm::vec2> sampleCurve(int totalSampleCount);
	static float evaluate(const std::vector<glm::vec2> &curve, float x);

	void Serialize(nlohmann::json &dict);
	void Deserialize(const nlohmann::json &dict);
};


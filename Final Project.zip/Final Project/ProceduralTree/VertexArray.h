#pragma once
#include <gl/glew.h>

struct VertexAttributeDesc
{
	int id;
	int size;
	GLenum type;
	GLenum normalized;
	int stride;
	void * offset;
	int divisor;
};

class VertexArray
{
	GLuint id=0;
public:
	~VertexArray();
	operator bool();

	void Create();

	void Bind();

	void SetVertexAttribute(VertexAttributeDesc *vertexAttribs, int vaCount);

	void DrawArrays(GLenum primitiveType, int start, int count);

	void DrawElements(GLenum primitiveType, void * offset, int count);

	void DrawArraysInstanced(GLenum primitiveType, int start, int count,int instanceCount);

	void DrawArraysInstancedBaseInstance(GLenum primitiveType, int start, int count,int instanceCount, int baseInstance);

	void Unbind();

	void Destroy();
};
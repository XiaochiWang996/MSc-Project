#pragma once
#include "BezierCurve.h"
#include "Mesh.h"
#include "Texture2D.h"
#include <memory>
#include <json.hpp>

struct Trunk;
struct Branch;
struct Twig;
struct Leaf;
struct ProceduralTreeData;

struct SplitSlot
{
	glm::vec3 position;
	glm::vec3 direction;
	float rootRadius;
};


struct ProceduralTreeDataListener
{
	virtual void onTreeDataChanged(ProceduralTreeData *treeData)=0;
	virtual void onRemoveFromTree(ProceduralTreeData *treeData) = 0;
};

struct ProceduralTreeData: std::enable_shared_from_this<ProceduralTreeData>
{
protected:
	Mesh mesh;
	int mainRandomSeed;
	int subRandomSeed[10];	// 0 for noised spine

	std::vector<ProceduralTreeDataListener*> dataChangeListeners;
	std::shared_ptr<ProceduralTreeData> child;
	std::weak_ptr<ProceduralTreeData> parent;

	virtual void SerializeSelf(nlohmann::json &dict) = 0;
	virtual void DeserializeSelf(const nlohmann::json &json) = 0;
public:
	ProceduralTreeData();
	int Seed();
	const Mesh & getMesh() const;
	virtual ~ProceduralTreeData();
	void newSeed();
	virtual void GenerateMesh() = 0;
	virtual std::vector<SplitSlot> getSplitSlot(int randomSeed,float startPos/*uniform length*/, float interval) = 0;

	void addDataChangeListener(ProceduralTreeDataListener* listerner);
	void removeDataChangeListener(ProceduralTreeDataListener* listerner);

	void setChildData(std::shared_ptr<ProceduralTreeData> newChild);
	std::shared_ptr<ProceduralTreeData> Child();

	std::vector<glm::vec3> getNoisedCurve(const std::vector<glm::vec3> &originalCurve, float noiseAmount, float noiseScale);
	void generateMeshFromCurve(const std::vector<glm::vec3> &curve,int radialSegments,const std::vector<glm::vec2> &radiusCurve,float radiusNoise,
		std::vector<glm::vec3> &positions, std::vector<glm::vec3> &normals, std::vector<glm::vec2> &uvs,std::vector<unsigned int> &indices);

	std::string texturePath;
	static nlohmann::json Serialize(std::shared_ptr<ProceduralTreeData> data);
	static std::shared_ptr<ProceduralTreeData> Deserialize(const nlohmann::json &json);
};

struct Tree
{
	Tree();
	std::shared_ptr<Trunk> trunk;
	void Serialize(nlohmann::json &dict);
	void Deserialize(const nlohmann::json & json);
};

struct Trunk:public ProceduralTreeData,public BezierCurveListener
{
	Trunk();
	float radius=0.3;
	int segments = 20;
	float barkNoise = 0.02;
	int radialSegments = 120;

	Simple2DCurve trunkRadiusCurve;
	BezierCurve spine;
	float spineNoise = 0.02;
	float spineNoiseScale = 1;

	// Inherited via ProceduralTreeData
	virtual void GenerateMesh() override;
	// Inherited via ProceduralTreeData
	virtual std::vector<SplitSlot> getSplitSlot(int randomSeed,float startPos/*uniform length*/,float interval) override;
protected:
	std::vector<glm::vec3> getNoisedTrunkSpine();

	// ͨ�� BezierCurveListener �̳�
	virtual void onCurveUpdate(BezierCurve * curve) override;

	// ͨ�� ProceduralTreeData �̳�
	virtual void SerializeSelf(nlohmann::json &dict) override;
	virtual void DeserializeSelf(const nlohmann::json & json) override;
};

struct Branch:public ProceduralTreeData
{
	float startSplitPos=0.5;	//uniform pos 0 root 1 tip
	float splitInterval=0.5;	//meter
	float radiusScale = 0.3;
	float seperation = 0.8;
	float stretch = 30;
	int segments = 20;
	int radialSegments = 30;
	float barkNoise = 0.02;
	float spineNoise = 0.02;
	float spineNoiseScale = 1;
	float gravityScale = 0;

	virtual std::vector<SplitSlot> getSplitSlot(int randomSeed, float startPos, float interval) override;
	virtual void GenerateMesh() override;

protected:
	std::vector<std::vector<glm::vec3>> getNoisedBranchSpines(const std::vector<SplitSlot> &slots);

	// ͨ�� ProceduralTreeData �̳�
	virtual void SerializeSelf(nlohmann::json &dict) override;
	virtual void DeserializeSelf(const nlohmann::json & json) override;
};

struct Twig :public ProceduralTreeData
{
	float startSplitPos = 0.9;	//uniform pos 0 root 1 tip
	float splitInterval = 1;	//meter
	float radius = 0.005;
	float seperation = 0.5;
	float stretch = 0.5;
	float gravityScale = 0;
	int segments = 10;
	int radialSegments = 6;

	virtual void GenerateMesh() override;
	virtual std::vector<SplitSlot> getSplitSlot(int randomSeed, float startPos, float interval) override;
protected:
	std::vector<std::vector<glm::vec3>> getTwigSpines(const std::vector<SplitSlot> &slots);

	// ͨ�� ProceduralTreeData �̳�
	virtual void SerializeSelf(nlohmann::json &dict) override;
	virtual void DeserializeSelf(const nlohmann::json & json) override;
};

struct Leaf :public ProceduralTreeData
{
	float startSplitPos = 0.95;	//uniform pos 0 root 1 tip
	float splitInterval = 1;	//meter
	float seperation = 0.5;
	float length = 0.05;
	float width = 0.05;

	virtual void GenerateMesh() override;
	virtual std::vector<SplitSlot> getSplitSlot(int randomSeed, float startPos, float interval) override;

	// ͨ�� ProceduralTreeData �̳�
	virtual void SerializeSelf(nlohmann::json &dict) override;
	virtual void DeserializeSelf(const nlohmann::json & json) override;
};






#include "Input.h"



Input::Input()
{
	for (auto &s : keyState)
	{
		s = false;
	}
	for (auto &s : oldKeyState)
	{
		s = false;
	}
	for (auto &s : buttonState)
	{
		s = false;
	}
	for (auto &s : oldButtonState)
	{
		s = false;
	}
	lastX = 0;
	lastY = 0;
	_x = 0;
	_y = 0;
}

void Input::onKey(int key, int scancode, int action, int mod)
{
	if (key>=0&&key<std::size(keyState))
	{
		keyState[key] = action != GLFW_RELEASE;
	}
	shift = mod & 1;
	ctrl = mod & 2;
	alt = mod & 4;
}

void Input::onMouseMove(float x, float y)
{
	_x = x;
	_y = y;
}

bool Input::getButton(int button)
{
	return buttonState[button];
}

bool Input::getButtonDown(int button)
{
	return (!oldButtonState[button]) && buttonState[button];
}

bool Input::getButtonUp(int button)
{
	return (!buttonState[button]) && oldButtonState[button];
}

bool Input::getKey(int key)
{
	return keyState[key];
}

bool Input::getKeyDown(int key)
{
	return (!oldKeyState[key]) && keyState[key];
}

bool Input::getKeyUp(int key)
{
	return (!keyState[key]) && oldKeyState[key];
}

bool Input::Shift()
{
	return shift;
}

bool Input::Ctrl()
{
	return ctrl;
}

bool Input::Alt()
{
	return alt;
}

void Input::onMouseButton(int button, int action, int mod)
{
	shift = mod & 1;
	ctrl = mod & 2;
	alt = mod & 4;
	buttonState[button] = action != GLFW_RELEASE;
}

void Input::endFrame()
{
	for (int i = 0; i < std::size(keyState); ++i)
	{
		oldKeyState[i] = keyState[i];
	}

	for (int i = 0; i < std::size(buttonState); ++i)
	{
		oldButtonState[i] = buttonState[i];
	}

	lastX = _x;
	lastY = _y;
}

float Input::x() const
{
	return _x;
}

float Input::y() const
{
	return _y;
}

float Input::deltaX() const
{
	return _x - lastX;
}

float Input::deltaY() const
{
	return _y - lastY;
}

#include "VertexArray.h"
#include <cassert>


VertexArray::~VertexArray()
{
	Destroy();
}

VertexArray::operator bool()
{
	return id;
}

void VertexArray::Create()
{
	glGenVertexArrays(1, &id);
}

void VertexArray::Bind()
{
	assert(id != 0 && "Vertex array not initialized!");
	glBindVertexArray(id);
}

void VertexArray::SetVertexAttribute(VertexAttributeDesc *vertexAttribs, int vaCount)
{
	assert(id != 0 && "Vertex array not initialized!");
	glBindVertexArray(id);
	for (int i = 0; i < vaCount; ++i)
	{
		auto &va = vertexAttribs[i];
		glEnableVertexAttribArray(va.id);
		glVertexAttribPointer(va.id, va.size, va.type, va.normalized, va.stride, va.offset);
		glVertexAttribDivisor(va.id, va.divisor);
	}
}

void VertexArray::DrawArrays(GLenum primitiveType, int start, int count)
{
	assert(id != 0 && "Vertex array not initialized!");
	glDrawArrays(primitiveType, start, count);
}

void VertexArray::DrawElements(GLenum primitiveType, void * offset, int count)
{
	assert(id != 0 && "Vertex array not initialized!");
	glDrawElements(primitiveType, count,GL_UNSIGNED_INT,offset);
}

void VertexArray::DrawArraysInstanced(GLenum primitiveType, int start, int count, int instanceCount)
{
	assert(id != 0 && "Vertex array not initialized!");
	glDrawArraysInstanced(primitiveType, start, count, instanceCount);
}

void VertexArray::DrawArraysInstancedBaseInstance(GLenum primitiveType, int start, int count, int instanceCount, int baseInstance)
{
	assert(id != 0 && "Vertex array not initialized!");
	glDrawArraysInstancedBaseInstance(primitiveType, start, count, instanceCount, baseInstance);
}

void VertexArray::Unbind()
{
	glBindVertexArray(0);
}

void VertexArray::Destroy()
{
	if (id)
	{
		glDeleteVertexArrays(1, &id);
		id = 0;
	}
}

#include "Window.h"
#include "ProceduralTreeWindow.h"
#include "mesh.h"

void main()
{
	glfwInit();
	auto w1 = new ProceduralTreeWindow();

	// Setup Dear ImGui context
	IMGUI_CHECKVERSION();
	ImGui::CreateContext();
	ImGuiIO& io = ImGui::GetIO(); (void)io;

	ImGui::StyleColorsDark();

	Window::run();
	glfwTerminate();
}
#pragma once
#include "shader.h"
#include <vector>
#include <glm/glm.hpp>
#include <map>

class Program
{
	GLuint id;
	std::string log;

	std::map<const char *, int> uniformLocations;

	int uniformLocation(const char *name);

public:
	const char * getLog() const;

	operator bool();

	Program();
	~Program();
	bool linkShaders(std::vector<Shader> shaders);
	void bind();
	void unbind();
	void destroy();

	void setUniform(const char *name, float value);
	void setUniform(const char *name, int value);
	void setUniform(const char *name, glm::vec2 value);
	void setUniform(const char *name, glm::vec3 value);
	void setUniform(const char *name, glm::vec4 value);
	void setUniform(const char *name, glm::mat3 value);
	void setUniform(const char *name, glm::mat4 value);
};


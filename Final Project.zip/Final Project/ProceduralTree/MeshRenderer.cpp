#include "MeshRenderer.h"

using namespace glm;
using namespace std;

MeshRenderer::MeshRenderer()
{
}


MeshRenderer::~MeshRenderer()
{
}

void MeshRenderer::CreateFromMesh(const Mesh &mesh)
{
	primitiveCount = mesh.position.size();

	VBO.Create(GL_ARRAY_BUFFER, (sizeof(vec3) + sizeof(vec3) + sizeof(vec2))*primitiveCount, 0);
	VBO.FillData(0, (void *)mesh.position.data(), primitiveCount * sizeof(vec3));
	VBO.FillData(primitiveCount *(sizeof(vec3)), (void *)mesh.normal.data(), primitiveCount * sizeof(vec3));
	VBO.FillData(primitiveCount *(sizeof(vec3) + sizeof(vec3)), (void *)mesh.uv.data(), primitiveCount * sizeof(vec2));

	VAO.Create();
	VAO.Bind();
	VBO.Bind();

	VertexAttributeDesc descs[] = {
		{ 0,3,GL_FLOAT,GL_FALSE,0,0,0 },
		{ 1,3,GL_FLOAT,GL_FALSE,0,(void *)(primitiveCount * sizeof(vec3)),0 },
		{ 2,2,GL_FLOAT,GL_FALSE,0,(void *)(primitiveCount * (sizeof(vec3) + sizeof(vec3))),0 },
	};
	VAO.SetVertexAttribute(descs, 3);

	VAO.Unbind();
	VBO.Unbind();
}

void MeshRenderer::UpdateMeshData(std::vector<glm::vec3> positions, std::vector<glm::vec3> normals, std::vector<glm::vec2> uvs, std::vector<unsigned int> indices)
{
	drawArrays = indices.empty();
	primitiveCount = drawArrays? positions.size(): indices.size();
	if (!EBO)
	{
		EBO.Create(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices[0])*indices.size(), indices.data());
	}
	else
	{
		EBO.Resize(sizeof(indices[0])*indices.size());
		EBO.FillData(0, indices.data(), sizeof(indices[0])*indices.size());
	}

	if (!VBO)
	{
		VBO.Create(GL_ARRAY_BUFFER, sizeof(positions[0])*positions.size() + sizeof(normals[0])*normals.size() + sizeof(uvs[0])*uvs.size(), 0);
	}
	else
	{
		VBO.Resize(sizeof(positions[0])*positions.size() + sizeof(normals[0])*normals.size() + sizeof(uvs[0])*uvs.size());
	}
	VBO.FillData(0, (void *)positions.data(), positions.size() * sizeof(vec3));
	VBO.FillData(sizeof(positions[0])*positions.size(), (void *)normals.data(), sizeof(normals[0])*normals.size());
	VBO.FillData(sizeof(positions[0])*positions.size() + sizeof(normals[0])*normals.size(), (void *)uvs.data(), sizeof(uvs[0])*uvs.size());

	if (!VAO)
	{
		VAO.Create();
	}
	VAO.Bind();
	VBO.Bind();
	if (!drawArrays)
	{
		EBO.Bind();
	}

	vector<VertexAttributeDesc> descs = {
		{ 0,3,GL_FLOAT,GL_FALSE,0,0,0 },
	};
	if (!normals.empty())
	{
		descs.push_back({
			1,3,GL_FLOAT,GL_FALSE,0,(void *)(sizeof(positions[0])*positions.size()),0
		});
	}
	if (!uvs.empty())
	{
		descs.push_back({
			2,2,GL_FLOAT,GL_FALSE,0,(void *)(sizeof(positions[0])*positions.size() + sizeof(normals[0])*normals.size()),0
		});
	}
	VAO.SetVertexAttribute(descs.data(), descs.size());

	VAO.Unbind();
	VBO.Unbind();
	if (!drawArrays)
	{
		EBO.Unbind();
	}
}

void MeshRenderer::Render(GLenum drawMode)
{
	if (tex)
	{
		tex->Bind(0);
	}
	VAO.Bind();
	if (drawArrays)
	{
		VAO.DrawArrays(drawMode, 0, primitiveCount);
	}
	else
	{
		VAO.DrawElements(drawMode, 0, primitiveCount);
	}
	VAO.Unbind();
}


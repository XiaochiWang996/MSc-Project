#pragma once

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/quaternion.hpp>

class Camera
{
protected:
	glm::vec3 _center;
	glm::vec3 _eulerAngles;
	float _fov;
	float _zNear;
	float _zFar;
	float _yTop;
	glm::vec2 _viewportSize;

	glm::vec3 _forward;
	glm::vec3 _up;
	glm::vec3 _right;

	glm::mat4 _view;
	glm::mat4 _projection;

	void RecaculateVectors();
	bool _perspective=true;

public:
	Camera();
	glm::vec3 Position() const;
	void Position(glm::vec3 val);
	glm::vec3 EulerAngles() const;
	void EulerAngles(glm::vec3 val);
	float ZNear() const;
	void ZNear(float val);
	float ZFar() const;
	void ZFar(float val);
	float FOV() const;
	void FOV(float fov);
	glm::vec3 Forward() const;
	glm::vec3 Up() const;
	glm::vec3 Right() const;
	glm::mat4 View() const;
	glm::mat4 Projection() const;
	glm::vec2 ViewportSize() const;
	void ViewportSize(glm::vec2 val);
	float Distance() const;
	void Distance(float val);
	glm::vec3 Center() const;
	void Center(glm::vec3 val);

	void ScreenToWorldRay(glm::vec2 screenPos,glm::vec3 &origin,glm::vec3 &dir);
};
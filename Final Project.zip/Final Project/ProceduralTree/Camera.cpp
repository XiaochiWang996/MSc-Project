#include "Camera.h"



void Camera::RecaculateVectors()
{
	auto rot = glm::mat3_cast(glm::quat(_eulerAngles));
	_right = rot[0];
	_up = rot[1];
	_forward = rot[2];
	_view = glm::lookAt(Center() - _forward*Distance(), Center(), _up);
	float ratio = _viewportSize.y == 0.0 ? 1 : _viewportSize.x / _viewportSize.y;

	if (_perspective)
	{
		_projection = glm::perspective(glm::radians(_fov), ratio, _zNear, _zFar);
	}
	else
	{
		_projection = glm::ortho(-_yTop*ratio, _yTop*ratio, -_yTop, _yTop, _zNear*_yTop, _zFar*_yTop);
	}

}

Camera::Camera()
{
	_fov = 60;
	_zNear = 0.1;
	_zFar = 100;
	_yTop = 3.0;
	_eulerAngles = { 0,glm::pi<float>(),0 };
	Center(glm::vec3(0));

	RecaculateVectors();
}

void Camera::Position(glm::vec3 val)
{
	Center(val + _forward*Distance());
	RecaculateVectors();
}

glm::vec3 Camera::Position() const
{
	return Center() - _forward*Distance();
}

void Camera::EulerAngles(glm::vec3 val)
{
	_eulerAngles = val;
	RecaculateVectors();
}

glm::vec3 Camera::EulerAngles() const
{
	return _eulerAngles;
}

void Camera::ZNear(float val)
{
	_zNear = val;
	RecaculateVectors();
}

float Camera::ZNear() const
{
	return _zNear;
}

void Camera::ZFar(float val)
{
	_zFar = val;
	RecaculateVectors();
}

float Camera::ZFar() const
{
	return _zFar;
}

float Camera::FOV() const
{
	return _fov;
}

void Camera::FOV(float fov)
{
	_fov = fov;
	RecaculateVectors();
}

glm::vec3 Camera::Forward() const
{
	return _forward;
}

glm::vec3 Camera::Up() const
{
	return _up;
}

glm::vec3 Camera::Right() const
{
	return _right;
}

glm::mat4 Camera::View() const
{

	return _view;
}

glm::mat4 Camera::Projection() const
{
	return _projection;
}

void Camera::ViewportSize(glm::vec2 val)
{
	_viewportSize = val;
	RecaculateVectors();
}

glm::vec2 Camera::ViewportSize() const
{
	return _viewportSize;
}

void Camera::Distance(float val)
{
	_yTop = val;
	RecaculateVectors();
}

float Camera::Distance() const
{
	return _yTop;
}

void Camera::Center(glm::vec3 val)
{
	_center = val;
	RecaculateVectors();
}

void Camera::ScreenToWorldRay(glm::vec2 screenPos, glm::vec3 & origin, glm::vec3 & dir)
{
	screenPos.y = _viewportSize.y - screenPos.y;
	screenPos /= _viewportSize;
	screenPos = screenPos * 2.0f - 1.0f;

	glm::mat4 ivp = glm::inverse(Projection()*View());
	glm::vec4 s{ screenPos.x,screenPos.y,-1,1 };
	glm::vec4 e{ screenPos.x,screenPos.y,1,1 };

	s = ivp*s;
	e = ivp*e;
	s /= s.w;
	e /= e.w;

	origin = glm::vec3(s);
	dir = glm::normalize(glm::vec3(e - s));
}

glm::vec3 Camera::Center() const
{
	return _center;
}

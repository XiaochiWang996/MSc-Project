#pragma once
#include <gl/glew.h>
#include <cassert>

class Buffer
{
	int size=0;
	GLuint id=0;
	GLenum target=0;
	GLenum hint = 0;
public:
	~Buffer();

	operator bool();

	void Create(GLenum target, int s=1024, void *data = 0, GLenum hint = GL_STATIC_DRAW);

	void Bind();

	void BindBufferBase(int location);

	void Unbind();

	void Resize(int size);
	
	void FillData(int offset, void *data, int size);
	
	void ReadData(int offset, int size, void *data);

	void Destroy();

};
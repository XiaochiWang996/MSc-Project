#include "Mesh.h"
#include <fstream>
#include <sstream>

using namespace std;
using namespace glm;

Mesh::Mesh()
{
}


Mesh::~Mesh()
{
}

void Mesh::loadObj(std::string path)
{
	ifstream ifs(path);
	if (ifs)
	{
		string line;
		vector<vec3> positions;
		vector<vec3> normals;
		vector<vec2> uvs;

		AABBMin = vec3(1);
		AABBMax = vec3(-1);

		position.clear();
		normal.clear();
		uv.clear();

		while (getline(ifs,line))
		{
			istringstream iss(line);
			string token;
			iss >> token;
			if (token == "v")
			{
				vec3 pos;
				iss >> pos.x >> pos.y >> pos.z;
				AABBMin = min(AABBMin, pos);
				AABBMax = max(AABBMax, pos);
				positions.push_back(pos);
			}
			if (token == "vn")
			{
				vec3 norm;
				iss >> norm.x >> norm.y >> norm.z;
				normals.push_back(norm);
			}
			if (token == "vt")
			{
				vec2 uv;
				iss >> uv.x >> uv.y;
				uvs.push_back(uv);
			}
			if (token=="f")
			{
				char delim;
				int vi, ti, ni;
				string vs;
				while (iss>>vs)
				{
					istringstream iss1(vs);
					iss1 >> vi >> delim >> ti >> delim >> ni;
					position.push_back(positions[vi - 1]);
					normal.push_back(normals[ni - 1]);
					uv.push_back(uvs[ti - 1]);
				}
			}
		}

		ifs.close();
	}
}

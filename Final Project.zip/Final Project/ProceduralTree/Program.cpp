#include "Program.h"
#include <glm/gtc/type_ptr.hpp>

using namespace glm;
using namespace std;

int Program::uniformLocation(const char * name)
{
	auto iter = uniformLocations.find(name);
	if (iter!=uniformLocations.end())
	{
		return iter->second;
	}
	uniformLocations[name] = glGetUniformLocation(id, name);
	return uniformLocations[name];
}

const char * Program::getLog() const
{
	return log.c_str();
}

Program::operator bool()
{
	return id;
}

Program::Program()
{
}


Program::~Program()
{
	destroy();
}

bool Program::linkShaders(std::vector<Shader> shaders)
{
	id = glCreateProgram();
	for (auto &s:shaders)
	{
		glAttachShader(id, s.id);
	}
	glLinkProgram(id);
	for (auto &s : shaders)
	{
		glDetachShader(id, s.id);
	}

	int status = 1;
	glGetProgramiv(id, GL_LINK_STATUS, &status);
	if (!status)
	{
		int logLen = 0;
		glGetProgramiv(id, GL_INFO_LOG_LENGTH, &logLen);
		log.resize(logLen + 1);
		glGetProgramInfoLog(id, logLen, 0, &log[0]);
		destroy();
	}
	return !id;
}

void Program::bind()
{
	glUseProgram(id);
}

void Program::unbind()
{
	glUseProgram(0);
}

void Program::destroy()
{
	if (id)
	{
		glDeleteProgram(id);
		id = 0;
	}
}

void Program::setUniform(const char *name, float value)
{
	glUniform1f(uniformLocation(name), value);
}

void Program::setUniform(const char *name, int value)
{
	glUniform1i(uniformLocation(name), value);
}

void Program::setUniform(const char *name, vec2 value)
{
	glUniform2fv(uniformLocation(name),1,value_ptr(value));
}

void Program::setUniform(const char *name, vec3 value)
{
	glUniform3fv(uniformLocation(name), 1, value_ptr(value));
}

void Program::setUniform(const char *name, vec4 value)
{
	glUniform4fv(uniformLocation(name), 1, value_ptr(value));
}

void Program::setUniform(const char *name, mat3 value)
{
	glUniformMatrix3fv(uniformLocation(name), 1,GL_FALSE,value_ptr(value));
}

void Program::setUniform(const char *name, mat4 value)
{
	glUniformMatrix4fv(uniformLocation(name), 1, GL_FALSE, value_ptr(value));
}

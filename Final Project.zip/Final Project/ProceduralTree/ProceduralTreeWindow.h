#pragma once
#include "Window.h"
#include "Camera.h"
#include "Program.h"
#include "FrameBuffer.h"
#include <random>
#include "imfilebrowser.h"
#include "VertexArray.h"
#include "Buffer.h"
#include "MeshRenderer.h"
#include "ProceduralTreeData.h"
#include <map>

class ProceduralTreeWindow :
	public Window,public ProceduralTreeDataListener,public BezierCurveListener
{
	Camera sceneCamera;
	Program litTexturedOpaque;
	Program litTexturedAlphaTest;
	Program unlitColorProgram;
	Program unlitTexturedPrgram;

	MeshRenderer axis;
	Texture2D axisTex;

	glm::vec3 lightDir = glm::vec3(1, 1, 0);
	glm::mat4 lightVP;

	MeshRenderer ground;

	FrameBuffer shadowFBO;
	Texture2D depthTexture;
	Program depthPassProgram;

	bool exportingObj = false;
	bool exportingScene = false;
	bool importingScene = false;
	bool settingTexture = false;

	ImGui::FileBrowser saveBrowser;
	ImGui::FileBrowser loadBrowser;

	bool loadFile(std::string &filePath);
	bool saveFile(std::string &filePath);

	Tree tree;

	std::map<ProceduralTreeData *, MeshRenderer> meshRenderers;

	//gizmo renderer
	BezierCurve *trunkCurve=0;
	MeshRenderer trunkCurveRenderer;
	MeshRenderer trunkCurveControlPointRenderer;
	MeshRenderer trunkCurveControlTangentRenderer;

	int currentEditControlPointIdx = -1;
	int currentEditControlPointHandleIdx = -1;
	void updateTrunkCurveGizmo();
	void editingCurve();

	Texture2D whiteTex;

	void depthPass(glm::mat4 VP);

	void updateTreeUI(Tree* tree);
	void updateProceduralTreeDataUI(std::shared_ptr<ProceduralTreeData> data);

	void updateTrunkUI(std::shared_ptr<Trunk> trunk);
	void updateBranchUI(std::shared_ptr<Branch> branch);
	void updateTwigUI(std::shared_ptr<Twig> twig);
	void updateLeafUI(std::shared_ptr<Leaf> leaf);

	void updateProceduralTreeTexture(std::shared_ptr<ProceduralTreeData> data);

	glm::vec3 uniformDirSample();

	std::random_device rd;
	float random(float min=0.0,float max=1.0);

	void loadScene(const char *filepath);
	void saveScene(const char *filepath);
	void exportAsObj(const char *filepath);

public:
	ProceduralTreeWindow();
	virtual void onInitialize();
	virtual void onRender();
	virtual void onUIUpdate();
	virtual void onUpdate();
	void drawGizmo();
	virtual void onResize(int w,int h);
private:
	void drawAxis();

	// ͨ�� ProceduralTreeDataListener �̳�
	virtual void onTreeDataChanged(ProceduralTreeData * treeData) override;
	virtual void onRemoveFromTree(ProceduralTreeData * treeData) override;

	// ͨ�� BezierCurveListener �̳�
	virtual void onCurveUpdate(BezierCurve * curve) override;
};

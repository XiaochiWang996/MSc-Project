#include "ProceduralTreeWindow.h"
#include <json.hpp>
#include <fstream>
#include <algorithm>
#include "BezierCurve.h"
#include "utility.h"
#include <experimental\filesystem>

using namespace nlohmann;
using namespace std;
using namespace glm;

using namespace std::experimental::filesystem::v1;

void ProceduralTreeWindow::loadScene(const char * filepath)
{
	json dict;
	ifstream(filepath) >> dict;

	tree.Deserialize(dict);
	shared_ptr<ProceduralTreeData> data = tree.trunk;
	while (data)
	{
		data->addDataChangeListener(this);
		if (!data->texturePath.empty())
		{
			int w, h;
			auto pixels = loadTexture(data->texturePath.c_str(), w, h);

			if (!pixels.empty())
			{
				meshRenderers[data.get()].tex = make_shared<Texture2D>();
				meshRenderers[data.get()].tex->Create(1, w, h, GL_RGBA8, GL_RGBA, GL_UNSIGNED_BYTE, pixels.data());
			}
		}
		data = data->Child();
	}

}

void ProceduralTreeWindow::saveScene(const char * filepath)
{
	json dict;
	tree.Serialize(dict);

	ofstream(filepath)<< dict.dump(2)<<endl;
}

void ProceduralTreeWindow::exportAsObj(const char * filepath)
{
	path objPath(filepath);
	objPath.replace_extension(".mtl");
	FILE *objFp = 0;
	FILE *mtlFp = 0;
	fopen_s(&objFp, filepath, "w");
	fopen_s(&mtlFp, objPath.string().c_str(), "w");

	if (objFp&&mtlFp)
	{
		shared_ptr<ProceduralTreeData> data = tree.trunk;
		
		int materialCount = 0;
		int meshCount = 0;
		fprintf(objFp,"mtllib %s\n", objPath.filename().string().c_str());

		int vertexOffset = 1;
		while (data)
		{
			fprintf(objFp, "o mesh%d\n", meshCount);
			fprintf(objFp, "usemtl material%d\n", materialCount);

			const Mesh &mesh = data->getMesh();
			for (auto &v : mesh.position)
			{
				fprintf(objFp, "v %f %f %f\n", v.x,v.y,v.z);
			}
			for (auto &vt : mesh.uv)
			{
				fprintf(objFp, "vt %f %f\n", vt.x, vt.y);
			}
			for (auto &vn : mesh.normal)
			{
				fprintf(objFp, "vn %f %f %f\n", vn.x, vn.y, vn.z);
			}

			for (size_t i = 0; i < mesh.indices.size()/3; i++)
			{
				int i1 = mesh.indices[3 * i] + vertexOffset;
				int i2 = mesh.indices[3 * i+1] + vertexOffset;
				int i3 = mesh.indices[3 * i+2] + vertexOffset;

				fprintf(objFp, "f %d/%d/%d %d/%d/%d %d/%d/%d\n", i1, i1, i1, i2, i2, i2, i3, i3, i3);
			}
			vertexOffset += mesh.position.size();
			fprintf(mtlFp, "newmtl material%d\n", materialCount);
			if (data->texturePath.empty())
			{
				fprintf(mtlFp, "	Kd 1 1 1\n");
			}
			else
			{
				fprintf(mtlFp, "	map_Kd %s\n", data->texturePath.c_str());
			}
			meshCount++;
			materialCount++;
			data = data->Child();
		}

		fclose(objFp);
		fclose(mtlFp);
	}


}

void Tree::Serialize(nlohmann::json &dict)
{
	if (this->trunk)
	{
		dict["trunk"] = ProceduralTreeData::Serialize(this->trunk);
	}
}

void Tree::Deserialize(const nlohmann::json & json)
{
	this->trunk = dynamic_pointer_cast<Trunk>(ProceduralTreeData::Deserialize(json["trunk"]));
}


void ProceduralTreeData::SerializeSelf(json &dict)
{
	dict["mainRandomSeed"] = mainRandomSeed;
	auto subSeeds = json::array();
	for (auto &seed : subRandomSeed)
	{
		subSeeds += seed;
	}
	dict["subRandomSeed"] = subSeeds;
	dict["texturePath"] = texturePath;
}

void ProceduralTreeData::DeserializeSelf(const json &dict)
{
	mainRandomSeed=dict["mainRandomSeed"];
	for (size_t i = 0; i < size(subRandomSeed); i++)
	{
		subRandomSeed[i] = dict["subRandomSeed"][i];
	}
	if (dict.contains("texturePath"))
	{
		texturePath = dict["texturePath"];
	}
}

void BezierCurve::Serialize(nlohmann::json &dict)
{
	dict["controlPoints"] = json::array();
	for (auto &cp: controlPoints)
	{
		auto jcp = json();
		jcp["position"] = { cp.position.x,cp.position.y,cp.position.z, };
		jcp["tangent"] = { cp.tangent.x,cp.tangent.y,cp.tangent.z, };
		jcp["leftHandleDis"] = cp.leftHandleDis;
		jcp["rightHandleDis"] = cp.rightHandleDis;
		dict["controlPoints"] += jcp;
	}
}

void BezierCurve::Deserialize(const nlohmann::json &dict)
{
	controlPoints.clear();
	for(auto &jcp: dict["controlPoints"])
	{
		BezierCurve::ControlPoint cp;
		cp.position = { jcp["position"][0],jcp["position"][1],jcp["position"][2] };
		cp.tangent = { jcp["tangent"][0],jcp["tangent"][1],jcp["tangent"][2] };
		cp.leftHandleDis = jcp["leftHandleDis"];
		cp.rightHandleDis = jcp["rightHandleDis"];

		controlPoints.push_back(cp);
	}
}

void Simple2DCurve::Serialize(nlohmann::json &dict)
{
	dict["knots"] = json::array();
	for (auto &knot : knots)
	{
		json jk = { knot.x,knot.y};
		dict["knots"] += jk;
	}
}

void Simple2DCurve::Deserialize(const nlohmann::json &dict)
{
	knots.clear();
	for (auto &jk : dict["knots"])
	{
		knots.push_back({ jk[0],jk[1] });
	}
}

void Trunk::SerializeSelf(json &dict)
{
	ProceduralTreeData::SerializeSelf(dict);
	dict["radius"]=radius;
	dict["segments"]=segments;
	dict["barkNoise"]=barkNoise;
	dict["radialSegments"]=radialSegments;

	dict["trunkRadiusCurve"]=json();
	trunkRadiusCurve.Serialize(dict["trunkRadiusCurve"]);
	dict["spine"]=json();
	spine.Serialize(dict["spine"]);
	dict["spineNoise"]=spineNoise;
	dict["spineNoiseScale"]=spineNoiseScale;
}

void Trunk::DeserializeSelf(const json & dict)
{
	ProceduralTreeData::DeserializeSelf(dict);
	radius = dict["radius"];
	segments = dict["segments"];
	barkNoise = dict["barkNoise"];
	radialSegments = dict["radialSegments"];

	trunkRadiusCurve.Deserialize(dict["trunkRadiusCurve"]);
	spine.Deserialize(dict["spine"]);
	spineNoise = dict["spineNoise"];
	spineNoiseScale = dict["spineNoiseScale"];
}

void Branch::SerializeSelf(json &dict)
{
	ProceduralTreeData::SerializeSelf(dict);
	dict["startSplitPos"] = startSplitPos;
	dict["splitInterval"] = splitInterval;
	dict["radiusScale"] = radiusScale;
	dict["seperation"] = seperation;
	dict["stretch"] = stretch;
	dict["segments"] = segments;
	dict["radialSegments"] = radialSegments;
	dict["barkNoise"] = barkNoise;
	dict["spineNoise"] = spineNoise;
	dict["spineNoiseScale"] = spineNoiseScale;
	dict["gravityScale"] = gravityScale;
}

void Branch::DeserializeSelf(const json & dict)
{
	ProceduralTreeData::DeserializeSelf(dict);
	startSplitPos = dict["startSplitPos"];
	splitInterval = dict["splitInterval"];
	radiusScale = dict["radiusScale"];
	seperation = dict["seperation"];
	stretch = dict["stretch"];
	segments = dict["segments"];
	radialSegments = dict["radialSegments"];
	barkNoise = dict["barkNoise"];
	spineNoise = dict["spineNoise"];
	spineNoiseScale = dict["spineNoiseScale"];
	gravityScale = dict["gravityScale"];
}

void Twig::SerializeSelf(json &dict)
{
	ProceduralTreeData::SerializeSelf(dict);
	dict["startSplitPos"] = startSplitPos;
	dict["splitInterval"] = splitInterval;
	dict["radius"] = radius;
	dict["seperation"] = seperation;
	dict["stretch"] = stretch;
	dict["gravityScale"] = gravityScale;
	dict["segments"] = segments;
	dict["radialSegments"] = radialSegments;
}

void Twig::DeserializeSelf(const json & dict)
{
	ProceduralTreeData::DeserializeSelf(dict);
	startSplitPos = dict["startSplitPos"];
	splitInterval = dict["splitInterval"];
	radius = dict["radius"];
	seperation = dict["seperation"];
	stretch = dict["stretch"];
	gravityScale = dict["gravityScale"];
	segments = dict["segments"];
	radialSegments = dict["radialSegments"];
}

void Leaf::SerializeSelf(json &dict)
{
	ProceduralTreeData::SerializeSelf(dict);
	dict["startSplitPos"] = startSplitPos;
	dict["splitInterval"] = splitInterval;
	dict["seperation"] = seperation;
	dict["length"] = length;
	dict["width"] = width;
}

void Leaf::DeserializeSelf(const json & dict)
{
	ProceduralTreeData::DeserializeSelf(dict);
	startSplitPos = dict["startSplitPos"];
	splitInterval = dict["splitInterval"];
	seperation = dict["seperation"];
	length = dict["length"];
	width = dict["width"];
}

json ProceduralTreeData::Serialize(std::shared_ptr<ProceduralTreeData> data)
{
	assert(data&&"procedural tree data is null");
	json dict;
	if (dynamic_pointer_cast<Trunk>(data))
	{
		dict["type"] = "Trunk";
	}
	if (dynamic_pointer_cast<Branch>(data))
	{
		dict["type"] = "Branch";
	}
	if (dynamic_pointer_cast<Twig>(data))
	{
		dict["type"] = "Twig";
	}
	if (dynamic_pointer_cast<Leaf>(data))
	{
		dict["type"] = "Leaf";
	}
	dict["data"] = json();

	data->SerializeSelf(dict["data"]);

	if (data->Child())
	{
		dict["data"]["child"] = Serialize(data->Child());
	}

	return dict;
}

std::shared_ptr<ProceduralTreeData> ProceduralTreeData::Deserialize(const json &dict)
{
	if (dict.contains("type"))
	{
		shared_ptr<ProceduralTreeData> data;
		if (dict["type"] == "Trunk")
		{
			data = make_shared<Trunk>();
		}
		if (dict["type"] == "Branch")
		{
			data = make_shared<Branch>();
		}
		if (dict["type"] == "Twig")
		{
			data = make_shared<Twig>();
		}
		if (dict["type"] == "Leaf")
		{
			data = make_shared<Leaf>();
		}

		data->DeserializeSelf(dict["data"]);

		if (dict["data"].contains("child"))
		{
			data->setChildData(Deserialize(dict["data"]["child"]));
		}
		return data;
	}
	return nullptr;
}

#pragma once
#include <gl/glew.h>
#include "texture2d.h"

class FrameBuffer
{
	GLuint id;
	int w, h;
public:
	operator bool();
	FrameBuffer();
	~FrameBuffer();

	void Create();
	void AttachColorTexture(Texture2D *texture, int attachmentId);
	void AttachDepthTexture(Texture2D *texture);

	void DrawBuffers(GLenum *buffers, int count);

	bool isComplete();

	void Bind();
	void Unbind();

	void Destroy();

	int Width();
	int Height();
};


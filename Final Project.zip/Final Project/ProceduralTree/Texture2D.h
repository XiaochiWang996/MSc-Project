#pragma once
#include <gl/glew.h>

class Texture2D
{
	friend class FrameBuffer;
protected:
	GLuint id=0;
	GLenum internalFormat;
	int w, h;
public:
	operator bool();

	Texture2D();
	~Texture2D();

	GLuint ID();

	void Create(int levels, int w, int h, GLenum internalFormat,GLenum format, GLenum type, void *data);
	void SetTextureFilter(GLenum magfilter, GLenum minFilter);
	void SetTextureWrapMod(GLenum wrapS, GLenum wrapT);
	void Resize(int w, int h);
	void FillData(int level,int x, int y, int w, int h, GLenum format, GLenum type, void *data);
	void Bind(int location);

	void Unbind();
	void Destroy();

	int Width();
	int Height();
};


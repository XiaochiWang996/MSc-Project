#pragma once
#include <glm/glm.hpp>
#include <vector>
#include <string>
class Mesh
{
public:
	Mesh();
	~Mesh();
	void loadObj(std::string path);
	std::vector<glm::vec3> position;
	std::vector<glm::vec3> normal;
	std::vector<glm::vec2> uv;

	std::vector<unsigned int> indices;

	glm::vec3 AABBMax;
	glm::vec3 AABBMin;
};


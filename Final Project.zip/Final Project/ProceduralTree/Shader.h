#pragma once
#include <gl/glew.h>
#include <string>

class Shader
{
	friend class Program;
	GLuint id=0;
	std::string log;
public:
	const char *getLog() const;
	operator bool();
	Shader();
	~Shader();
	bool loadFromSrc(GLenum shaderType, const char *src);
	bool loadFromFile(GLenum shaderType, const char *path);
	void destroy();
};


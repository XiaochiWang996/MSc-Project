#include "BezierCurve.h"
#include <algorithm>
using namespace std;
using namespace glm;


void BezierCurve::updateCurve()
{
	for (auto &cb: curveUpdateListeners)
	{
		cb->onCurveUpdate(this);
	}
}

BezierCurve::BezierCurve()
{
}


BezierCurve::~BezierCurve()
{
}

void BezierCurve::addListener(BezierCurveListener *listener)
{
	listener->onCurveUpdate(this);
	curveUpdateListeners.insert(listener);
}

void BezierCurve::removeListener(BezierCurveListener * listener)
{
	curveUpdateListeners.erase(listener);
}

int BezierCurve::controlPointCount()
{
	return controlPoints.size();
}

BezierCurve::ControlPoint BezierCurve::getControlPoint(int index)
{
	if (index>=0&&index<controlPoints.size())
	{
		return controlPoints[index];
	}
	return ControlPoint();
}

void BezierCurve::updateControlPoint(int index, const ControlPoint & cp)
{
	if (index >= 0 && index<controlPoints.size())
	{
		controlPoints[index]=cp;
		updateCurve();
	}
}

void BezierCurve::insertControlPoint(int index, const ControlPoint & cp)
{
	index = glm::clamp(index, 0, (int)controlPoints.size());
	controlPoints.insert(controlPoints.begin() + index, cp);
	updateCurve();
}

void BezierCurve::deleteControlPoint(int index)
{
	if (index >= 0 && index < controlPoints.size())
	{
		controlPoints.erase(controlPoints.begin() + index);
		updateCurve();
	}
}

std::vector<glm::vec3> BezierCurve::sampleCurve(int segmentCount)
{
	std::vector<glm::vec3> curve;
	for (auto &cp : controlPoints)
	{
		cp.tangent = normalize(cp.tangent);
	}
	if (controlPoints.size()>1)
	{
		for (size_t i = 0; i < controlPoints.size() - 1; i++)
		{
			vec3 p0 = controlPoints[i].position;
			vec3 p1 = controlPoints[i].position + controlPoints[i].tangent*controlPoints[i].rightHandleDis;
			vec3 p2 = controlPoints[i + 1].position - controlPoints[i + 1].tangent*controlPoints[i + 1].leftHandleDis;
			vec3 p3 = controlPoints[i + 1].position;

			for (size_t j = 0; j < segmentCount; j++)
			{
				float w = float(j) / segmentCount;
				curve.push_back(pow(1 - w, 3)*p0 + 3 * pow(1 - w, 2)*w*p1 + 3 * (1 - w)*w*w*p2 + pow(w, 3)*p3);
			}
		}
		curve.push_back(controlPoints.rbegin()->position);
	}


	return curve;
}
std::vector<glm::vec2> Simple2DCurve::sampleCurve(int totalSampleCount)
{
	sort(knots.begin(), knots.end(), [](auto &k1, auto &k2) {return k1.x < k2.x; });
	std::vector<glm::vec2> curve;
	int sampleCount = totalSampleCount / knots.size() + 1;
	if (knots.size()<2)
	{
		return curve;
	}
	for (size_t i = 0; i < knots.size()-1; i++)
	{
		int lIdx = clamp<int>(i - 1, 0, knots.size() - 1);
		int mIdx = clamp<int>(i + 1, 0, knots.size() - 1);
		int rIdx = clamp<int>(i + 2, 0, knots.size() - 1);

		vec2 lTangent = knots[mIdx] - knots[lIdx];
		lTangent /= lTangent.x;
		vec2 rTangent = knots[rIdx] - knots[i];
		rTangent /= rTangent.x;

		float dis= (knots[i+1] - knots[i]).x*0.5;

		vec2 p0 = knots[i];
		vec2 p3 = knots[i+1];
		vec2 p1 = p0 + lTangent*dis;
		vec2 p2 = p3 - rTangent*dis;


		for (size_t i = 0; i <sampleCount; i++)
		{
			float w = float(i) / sampleCount;
			curve.push_back(pow(1 - w, 3)*p0 + 3 * pow(1 - w, 2)*w*p1 + 3 * (1 - w)*w*w*p2 + pow(w, 3)*p3);
		}
	}
	curve.push_back(*knots.rbegin());

	return curve;
}

float Simple2DCurve::evaluate(const std::vector<glm::vec2>& curve, float x)
{
	auto i = 0;
	for (; i < curve.size() - 1; i++)
	{
		if (curve[i].x > x)
			break;

	}
	if (i == curve.size())
	{
		return curve.rbegin()->y;
	}
	if (i == 0)
	{
		return curve.begin()->y;
	}
	float w = (x - curve[i - 1].x) / (curve[i].x - curve[i - 1].x);
	return curve[i - 1].y*(1 - w) + curve[i].y*w;
}


#define STB_IMAGE_IMPLEMENTATION
#include "utility.h"

std::vector<unsigned char> loadTexture(const char * path, int & w, int & h)
{
	auto data = std::vector<unsigned char>();
	auto buffer = stbi_load(path, &w, &h, 0, 4);
	if (buffer)
	{
		data = std::vector<unsigned char>(buffer,buffer + 4 * w*h);
		free(buffer);
	}
	return data;
}

#include "ProceduralTreeWindow.h"
#include <filesystem>
#include <future>
#include <mutex>
#include "utility.h"
#include "Mesh.h"

using namespace glm;
using namespace std;
using namespace std::experimental::filesystem::v1;


bool ProceduralTreeWindow::loadFile(string & filePath)
{
	ImguiIdHelper id((long long)filePath.c_str());
	loadBrowser.Display();
	if (loadBrowser.HasSelected())
	{
		filePath = loadBrowser.GetSelected().string();
		loadBrowser.ClearSelected();
		return true;
	}
	return false;
}

bool ProceduralTreeWindow::saveFile(string & filePath)
{
	ImguiIdHelper id((long long)filePath.c_str());
	saveBrowser.Display();
	if (saveBrowser.HasSelected())
	{
		filePath = saveBrowser.GetSelected().string();
		saveBrowser.ClearSelected();
		return true;
	}
	return false;
}

void ProceduralTreeWindow::updateTrunkCurveGizmo()
{
	trunkCurveRenderer.UpdateMeshData(trunkCurve->sampleCurve(50), {}, {});

	vector<vec3> controlPointsData;
	vector<vec3> controlPointsHandleData;

	for (int i = 0; i<trunkCurve->controlPointCount(); ++i)
	{
		auto cp = trunkCurve->getControlPoint(i);
		controlPointsData.push_back(cp.position);
		controlPointsData.push_back(cp.position - cp.tangent*cp.leftHandleDis);
		controlPointsData.push_back(cp.position + cp.tangent*cp.rightHandleDis);

		controlPointsHandleData.push_back(cp.position);
		controlPointsHandleData.push_back(cp.position - cp.tangent*cp.leftHandleDis);
		controlPointsHandleData.push_back(cp.position);
		controlPointsHandleData.push_back(cp.position + cp.tangent*cp.rightHandleDis);
	}

	trunkCurveControlPointRenderer.UpdateMeshData(controlPointsData, {}, {});
	trunkCurveControlTangentRenderer.UpdateMeshData(controlPointsHandleData, {}, {});
}

void ProceduralTreeWindow::editingCurve()
{
	if (trunkCurve)
	{
		int segmentCount = 50;
		auto vp = sceneCamera.Projection()*sceneCamera.View();
		vec2 uv = { input.x(),height - input.y() };
		vec2 viewport = { width,height };
		if (currentEditControlPointIdx==-1 && input.getButtonDown(0))
		{
			if (input.getKey('I'))
			{
				float selectDis = 5;
				auto points = trunkCurve->sampleCurve(segmentCount);
				for (size_t i = 0; i < points.size(); i++)
				{
					vec4 ndc = vp*vec4(points[i], 1);
					ndc /= ndc.w;
					ndc = ndc*0.5f + 0.5f;
					vec2 sp = viewport*vec2{ ndc.x,ndc.y };
					if (length(sp - uv)<selectDis)
					{
						int index = i / segmentCount + 1;
						BezierCurve::ControlPoint cp = { points[i] };

						float t = float(i % segmentCount) / segmentCount;
						vector<vec3> knots;
						for (size_t i = 0; i < 4; i++)
						{

						}

						int lIdx = clamp(i - 1, 0u, points.size() - 1);
						int rIdx = clamp(i + 1, 0u, points.size() - 1);
						vec3 tangent = points[rIdx] - points[lIdx];
						cp.leftHandleDis = lIdx == i ? 1 : length(points[i] - points[lIdx])*segmentCount*0.05;
						cp.rightHandleDis = rIdx == i ? 1 : length(points[rIdx] - points[i])*segmentCount*0.05;
						cp.tangent = normalize(tangent);
						trunkCurve->insertControlPoint(index, cp);
						break;
					}
				}
			}
			else if (input.getKey('U') && trunkCurve->controlPointCount()>2)
			{
				float selectDis = 10;
				for (size_t i = 0; i < trunkCurve->controlPointCount(); i++)
				{
					vec4 ndc = vp*vec4(trunkCurve->getControlPoint(i).position, 1);
					ndc /= ndc.w;
					ndc = ndc*0.5f + 0.5f;
					vec2 sp = viewport*vec2{ ndc.x,ndc.y };
					if (length(sp - uv)<selectDis)
					{
						trunkCurve->deleteControlPoint(i);
						break;
					}
				}
			}
			else
			{
				float selectDis = 10;
				for (size_t i = 0; i < trunkCurve->controlPointCount()&& currentEditControlPointIdx == -1; i++)
				{
					auto cp = trunkCurve->getControlPoint(i);
					vector<vec4> handles = {
						{ cp.position - cp.tangent*cp.leftHandleDis,1 },
						{ cp.position + cp.tangent*cp.rightHandleDis,1 },
						{ cp.position,1 },
					};
					for (size_t j = 0; j < handles.size(); j++)
					{
						vec4 ndc = vp*handles[j];
						ndc /= ndc.w;
						ndc = ndc*0.5f + 0.5f;
						vec2 sp = viewport*vec2{ ndc.x,ndc.y };
						if (length(sp - uv)<selectDis)
						{
							currentEditControlPointIdx = i;
							currentEditControlPointHandleIdx = j;
							break;
						}
					}
				}
			}
		}

		if (currentEditControlPointIdx!=-1)
		{
			auto cp = trunkCurve->getControlPoint(currentEditControlPointIdx);
			vector<vec4> handles = {
				{ cp.position - cp.tangent*cp.leftHandleDis,1 },
				{ cp.position + cp.tangent*cp.rightHandleDis,1 },
				{ cp.position,1 },
			};

			vec4 ndc = vp*handles[currentEditControlPointHandleIdx];
			ndc /= ndc.w;
			ndc.x = uv.x/width * 2 - 1;
			ndc.y = uv.y/height * 2 - 1;

			vec4 worldPos = inverse(vp)*ndc;
			worldPos /= worldPos.w;
			switch(currentEditControlPointHandleIdx)
			{
			case 0:
				cp.leftHandleDis = length(vec3(worldPos) - cp.position);
				if (cp.leftHandleDis>1e-6)
				{
					cp.tangent = normalize(cp.position -vec3( worldPos));
				}
				break;
			case 1:
				cp.rightHandleDis = length(vec3(worldPos) - cp.position);
				if (cp.rightHandleDis>1e-6)
				{
					cp.tangent = normalize(vec3(worldPos) - cp.position);
				}
				break;
			case 2:
				cp.position = vec3(worldPos);
				break;
			}

			trunkCurve->updateControlPoint(currentEditControlPointIdx, cp);
		}

		if (input.getButtonUp(0))
		{
			currentEditControlPointIdx = -1;
		}
	}
}

void ProceduralTreeWindow::depthPass(glm::mat4 VP)
{
	ViewPortGuard vpg;
	shadowFBO.Bind();
	glClearDepth(1.0);
	glClear(GL_DEPTH_BUFFER_BIT);

	glEnable(GL_POLYGON_OFFSET_FILL);
	glPolygonOffset(1.5, 2);

	depthPassProgram.bind();

	for (auto &kv :meshRenderers)
	{
		depthPassProgram.setUniform("MVP", VP*kv.second.modelMatrix);
		kv.second.Render();
	}

	shadowFBO.Unbind();
	glDisable(GL_POLYGON_OFFSET_FILL);
}

void ProceduralTreeWindow::updateTreeUI(Tree * tree)
{
	ImguiIdHelper ih((long long)tree);
	if (ImGui::TreeNode("Tree"))
	{
		string path;
		if (ImGui::Button("import scene data"))
		{
			loadBrowser.Open();
			importingScene = true;
		}
		if (importingScene&&loadFile(path))
		{
			loadScene(path.c_str());
			importingScene = false;
		}
		if (tree->trunk)
		{
			ImGui::SameLine();
			if (ImGui::Button("export scene data"))
			{
				saveBrowser.Open();
				exportingScene = true;
			}
			ImGui::SameLine();
			if (ImGui::Button("export obj mesh"))
			{
				saveBrowser.Open();
				exportingObj = true;
			}

			if (exportingScene&&saveFile(path))
			{
				saveScene(path.c_str());
				exportingScene = false;
			}
			if (exportingObj&&saveFile(path))
			{
				exportAsObj(path.c_str());
				exportingObj = false;
			}

			if (ImGui::Button("delete trunk"))
			{
				tree->trunk = nullptr;
			}
		}
		else
		{
			if (ImGui::Button("add trunk"))
			{
				tree->trunk = make_shared<Trunk>();
				tree->trunk->addDataChangeListener(this);
			}
		}
		updateProceduralTreeDataUI(tree->trunk);
		ImGui::TreePop();
	}
}

void ProceduralTreeWindow::updateProceduralTreeDataUI(std::shared_ptr<ProceduralTreeData> data)
{
	if (!data)
	{
		return;
	}
	ImguiIdHelper ih((long long)data.get());

	if (dynamic_pointer_cast<Trunk>(data))
	{
		updateTrunkUI(dynamic_pointer_cast<Trunk>(data));
	}
	if (dynamic_pointer_cast<Branch>(data))
	{
		updateBranchUI(dynamic_pointer_cast<Branch>(data));
	}
	if (dynamic_pointer_cast<Twig>(data))
	{
		updateTwigUI(dynamic_pointer_cast<Twig>(data));
	}
	if (dynamic_pointer_cast<Leaf>(data))
	{
		updateLeafUI(dynamic_pointer_cast<Leaf>(data));
	}
}

void ProceduralTreeWindow::updateTrunkUI(std::shared_ptr<Trunk> data)
{
	if (!data)
	{
		return;
	}

	if (ImGui::TreeNode("Trunk"))
	{
		ImguiIdHelper ih((long long)data.get());
		if (ImGui::TreeNode("Parameters"))
		{
			if (ImGui::Button("Update Mesh"))
			{
				data->newSeed();
			}
			if (ImGui::Button(trunkCurve ?"complete curve":"edit curve"))
			{
				if (trunkCurve)
				{
					trunkCurve->removeListener(this);
					trunkCurve = nullptr;
				}
				else
				{
					trunkCurve = &data->spine;
					trunkCurve->addListener(this);
				}
			}
			if (ImGui::SliderInt("segments", &(dynamic_pointer_cast<Trunk>(data)->segments), 10, 100))
			{
				data->GenerateMesh();
			}
			if (ImGui::SliderFloat("radius", &(dynamic_pointer_cast<Trunk>(data)->radius), 0.1, 1))
			{
				data->GenerateMesh();
			}
			if (ImGui::SliderFloat("spine noise amount", &(dynamic_pointer_cast<Trunk>(data)->spineNoise), 0, 1))
			{
				data->GenerateMesh();
			}
			if (ImGui::SliderFloat("spine noise scale", &(dynamic_pointer_cast<Trunk>(data)->spineNoiseScale), 0.1, 10))
			{
				data->GenerateMesh();
			}
			if (ImGui::SliderFloat("bark noise", &(dynamic_pointer_cast<Trunk>(data)->barkNoise), 0, 1))
			{
				data->GenerateMesh();
			}
			auto radialCurve = data->trunkRadiusCurve.sampleCurve(100);
			ImGui::PlotLines("trunk radius curve", [](void *curve2d, int idx) {return Simple2DCurve::evaluate(*(vector<vec2>*)curve2d, idx*0.01); }, &radialCurve, 101,
				0, 0, FLT_MAX, FLT_MAX, ImVec2{ 0,200 });
			bool updateCurve = false;
			for (size_t i = 0; i < data->trunkRadiusCurve.knots.size(); i++)
			{
				ImguiIdHelper idHelper((long long)&data->trunkRadiusCurve.knots[i]);
				updateCurve = ImGui::SliderFloat("radius", &data->trunkRadiusCurve.knots[i].y, 0, 5) || updateCurve;
			}
			if (updateCurve)
			{
				data->GenerateMesh();
			}
			updateProceduralTreeTexture(data);
		}
		if (data->Child())
		{
			if (ImGui::Button("delete child"))
			{
				data->setChildData(nullptr);
			}
		}
		else
		{
			if (ImGui::Button("add branch"))
			{
				auto child = make_shared<Branch>();
				data->setChildData(child);
				child->addDataChangeListener(this);
			}
		}

		ImGui::TreePop();
	}
	updateProceduralTreeDataUI(data->Child());
}

void ProceduralTreeWindow::updateBranchUI(std::shared_ptr<Branch> data)
{
	if (!data)
	{
		return;
	}
	if (ImGui::TreeNode("Branch"))
	{

		ImguiIdHelper ih((long long)data.get());
		if (ImGui::TreeNode("Parameters"))
		{
			ImGui::Text("seed:%d", data->Seed());
			if (ImGui::Button("Update Mesh"))
			{
				data->newSeed();
			}
			if (ImGui::SliderInt("segments", &(data->segments), 10, 100))
			{
				data->GenerateMesh();
			}
			if (ImGui::SliderFloat("seperation", &(data->seperation), 0.1, 1))
			{
				data->GenerateMesh();
			}
			if (ImGui::SliderFloat("radius", &(data->radiusScale), 0.1, 1))
			{
				data->GenerateMesh();
			}
			if (ImGui::SliderFloat("stretch", &(data->stretch), 10, 100))
			{
				data->GenerateMesh();
			}
			if (ImGui::SliderFloat("gravity Scale", &(data->gravityScale), -10, 10, "%.4f"))
			{
				data->GenerateMesh();
			}
			if (ImGui::SliderFloat("spine noise amount", &(data->spineNoise), 0, 1))
			{
				data->GenerateMesh();
			}
			if (ImGui::SliderFloat("spine noise scale", &(data->spineNoiseScale), 0.1, 10))
			{
				data->GenerateMesh();
			}
			if (ImGui::SliderFloat("bark noise", &(data->barkNoise), 0, 1))
			{
				data->GenerateMesh();
			}

			if (ImGui::SliderFloat("split interval", &(data->splitInterval), 0.1, 10))
			{
				data->GenerateMesh();
			}

			if (ImGui::SliderFloat("split pos", &(data->startSplitPos), 0.1, 1))
			{
				data->GenerateMesh();
			}
			updateProceduralTreeTexture(data);
		}
		if (data->Child())
		{
			if (ImGui::Button("delete child"))
			{
				data->setChildData(nullptr);
			}
		}
		else
		{
			if (ImGui::Button("add branch"))
			{
				auto child = make_shared<Branch>();
				data->setChildData(child);
				child->addDataChangeListener(this);
			}
			if (ImGui::Button("add twig"))
			{
				auto child = make_shared<Twig>();
				data->setChildData(child);
				child->addDataChangeListener(this);
			}
		}
		ImGui::TreePop();
	}
	updateProceduralTreeDataUI(data->Child());
}

void ProceduralTreeWindow::updateTwigUI(std::shared_ptr<Twig> data)
{
	if (!data)
	{
		return;
	}
	if (ImGui::TreeNode("Twig"))
	{
		ImguiIdHelper ih((long long)data.get());
		if (ImGui::TreeNode("Parameters"))
		{
			ImGui::Text("seed:%d", data->Seed());
			if (ImGui::Button("Update Mesh"))
			{
				data->newSeed();
			}
			if (ImGui::SliderInt("segments", &(data->segments), 10, 100))
			{
				data->GenerateMesh();
			}
			if (ImGui::SliderFloat("seperation", &(data->seperation), 0.1, 1))
			{
				data->GenerateMesh();
			}
			if (ImGui::SliderFloat("radius", &(data->radius), 0.001, 0.01, "%.4f"))
			{
				data->GenerateMesh();
			}
			if (ImGui::SliderFloat("stretch", &(data->stretch), 0.1, 10))
			{
				data->GenerateMesh();
			}
			if (ImGui::SliderFloat("gravity Scale", &(data->gravityScale), -10, 10, "%.4f"))
			{
				data->GenerateMesh();
			}
			if (ImGui::SliderFloat("split interval", &(data->splitInterval), 0.1, 10))
			{
				data->GenerateMesh();
			}

			if (ImGui::SliderFloat("split pos", &(data->startSplitPos), 0.1, 1))
			{
				data->GenerateMesh();
			}
			updateProceduralTreeTexture(data);
		}
		if (data->Child())
		{
			if (ImGui::Button("delete child"))
			{
				data->setChildData(nullptr);
			}
		}
		else
		{
			if (ImGui::Button("add leaf"))
			{
				auto child = make_shared<Leaf>();
				data->setChildData(child);
				child->addDataChangeListener(this);
			}
		}
		ImGui::TreePop();
	}
	updateProceduralTreeDataUI(data->Child());
}

void ProceduralTreeWindow::updateLeafUI(std::shared_ptr<Leaf> data)
{
	if (!data)
	{
		return;
	}
	if (ImGui::TreeNode("Leaf"))
	{
		ImguiIdHelper ih((long long)data.get());
		ImGui::Text("seed:%d", data->Seed());
		if (ImGui::Button("Update Mesh"))
		{
			data->newSeed();
		}
		if (ImGui::SliderFloat("seperation", &(data->seperation), 0.1, 1))
		{
			data->GenerateMesh();
		}
		if (ImGui::SliderFloat("width", &(data->width), 0.01, 1, "%.4f"))
		{
			data->GenerateMesh();
		}
		if (ImGui::SliderFloat("length", &(data->length), 0.01, 1, "%.4f"))
		{
			data->GenerateMesh();
		}

		if (ImGui::SliderFloat("split interval", &(data->splitInterval), 0.001, 1, "%.03f"))
		{
			data->GenerateMesh();
		}

		if (ImGui::SliderFloat("split pos", &(data->startSplitPos), 0.1, 1))
		{
			data->GenerateMesh();
		}

		updateProceduralTreeTexture(data);
		ImGui::TreePop();
	}
}

void ProceduralTreeWindow::updateProceduralTreeTexture(std::shared_ptr<ProceduralTreeData> data)
{
	if (meshRenderers.find(data.get())== meshRenderers.end())
	{
		return;
	}
	auto &renderer = meshRenderers[data.get()];
	ImGui::Separator();
	string path;
	if (ImGui::Button("set texture"))
	{
		loadBrowser.Open();
		settingTexture = true;
	}

	if (settingTexture&&loadFile(path))
	{
		settingTexture = false;
		int w, h;
		auto pixels = loadTexture(path.c_str(), w, h);

		if (!pixels.empty())
		{
			renderer.tex = make_shared<Texture2D>();
			renderer.tex->Create(1, w, h, GL_RGBA8, GL_RGBA, GL_UNSIGNED_BYTE, pixels.data());
			data->texturePath = path;
		}

	}

	ImGui::SameLine();
	if (ImGui::Button("clear texture"))
	{
		data->texturePath = "";
		renderer.tex = nullptr;
	}
}

glm::vec3 ProceduralTreeWindow::uniformDirSample()
{
	float theta, phi;
	theta = pi<float>() *random(0,2);
	phi = acos(random(-1,1));
	return vec3{ cos(theta)*sin(phi),sin(theta)*sin(phi),cos(phi) };
}

float ProceduralTreeWindow::random(float min, float max)
{
	uniform_real_distribution<float> urd(min, max);
	return urd(rd);
}

ProceduralTreeWindow::ProceduralTreeWindow() :
	Window("ProceduralTreeSimple"),
	saveBrowser(ImGuiFileBrowserFlags_EnterNewFilename)
{
	/*

	trunk->radius = 0.187;
	trunk->trunkRadiusCurve.knots = {
		{ 0,1 },
		{ 0.2,0.79 },
		{ 0.4,0.581 },
		{ 0.6,0.371 },
		{ 0.8,0.177 },
		{ 1,0 },
	};

	branch->splitInterval = 0.132;
	branch->startSplitPos = 0.236;
	branch->stretch = 54;
	branch->radiusScale = 0.5;

	branch1->splitInterval = 0.164;
	branch1->startSplitPos = 0.254;
	branch1->stretch = 54;
	branch1->radiusScale = 0.5;

	twig->splitInterval = 0.1;
	twig->startSplitPos = 0.347;
	twig->stretch = 0.196;
	twig->radius = 0.0018;

	leaf->width = 0.1090;
	leaf->length = 0.1026;
	leaf->splitInterval = 0.03;
	leaf->startSplitPos = 0.123;

	trunk->GenerateMesh();
	*/
}

void ProceduralTreeWindow::onInitialize()
{
	Window::onInitialize();
	{
		Shader vert, frag;
		vert.loadFromFile(GL_VERTEX_SHADER, "assets//shaders//litTexturedOpaque.vert");
		frag.loadFromFile(GL_FRAGMENT_SHADER, "assets//shaders//litTexturedOpaque.frag");
		litTexturedOpaque.linkShaders({ vert,frag });
	}

	{
		Shader vert, frag;
		vert.loadFromFile(GL_VERTEX_SHADER, "assets//shaders//litTexturedOpaque.vert");
		frag.loadFromFile(GL_FRAGMENT_SHADER, "assets//shaders//litTexturedAlphaTest.frag");
		litTexturedAlphaTest.linkShaders({ vert,frag });
	}

	{
		Shader depthOnlyShader;
		depthOnlyShader.loadFromFile(GL_VERTEX_SHADER, "assets//shaders//depthPass.vert");
		depthPassProgram.linkShaders({ depthOnlyShader });
	}

	{
		Shader vert, frag;
		vert.loadFromFile(GL_VERTEX_SHADER, "assets//shaders//unlitColor.vert");
		frag.loadFromFile(GL_FRAGMENT_SHADER, "assets//shaders//unlitColor.frag");
		unlitColorProgram.linkShaders({ vert,frag });
	}

	{
		Shader vert, frag;
		vert.loadFromFile(GL_VERTEX_SHADER, "assets//shaders//unlitTextured.vert");
		frag.loadFromFile(GL_FRAGMENT_SHADER, "assets//shaders//unlitTextured.frag");
		unlitTexturedPrgram.linkShaders({ vert,frag });
	}

	{
		Mesh axisMesh;
		axisMesh.loadObj("assets//models//axis.obj");
		axis.CreateFromMesh(axisMesh);

		int w, h;
		auto pixels = loadTexture("assets//textures//axis.bmp", w, h);
		if (!pixels.empty())
		{
			axisTex.Create(1, w, h, GL_RGBA8, GL_RGBA, GL_UNSIGNED_BYTE, pixels.data());
		}
	}

	{
		Mesh groundMesh;
		groundMesh.loadObj("assets//models//ground.obj");
		ground.CreateFromMesh(groundMesh);
	}


	unsigned char whitePixe[] = { 255,255,255,255 };
	whiteTex.Create(1, 1, 1, GL_RGBA8, GL_RGBA, GL_UNSIGNED_BYTE, whitePixe);

	lightVP = ortho<float>(-10, 10, -10, 10, -50, 50)*lookAt(vec3(0,5,0) + lightDir, vec3(0, 5, 0), vec3(0, 1, 0));

	shadowFBO.Create();
	depthTexture.Create(1, 1024, 1024, GL_DEPTH_COMPONENT32F, GL_DEPTH_COMPONENT, GL_FLOAT, 0);
	depthTexture.SetTextureFilter(GL_LINEAR, GL_LINEAR);
	depthTexture.SetTextureWrapMod(GL_CLAMP, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE, GL_COMPARE_REF_TO_TEXTURE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_FUNC, GL_LESS);

	shadowFBO.AttachDepthTexture(&depthTexture);
	if (!shadowFBO)
	{
		printf("Framebuffer incomplete!!!\n");
	}

	if (!litTexturedOpaque)
	{
		printf("Program Error:\n%s", litTexturedOpaque.getLog());
	}

	glEnable(GL_DEPTH_TEST);
	sceneCamera.Center({ 0,5,0 });
	sceneCamera.Distance(15);
	sceneCamera.EulerAngles({0.25,0,0 });
	sceneCamera.ViewportSize({width,height});
}

void ProceduralTreeWindow::onRender()
{
	depthPass(lightVP);

	glBindFramebuffer(GL_FRAMEBUFFER, 0);
	glClearColor(0.3, 0.3, 0.3, 1);
	glClearDepth(1);
	glClearStencil(0);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT|GL_STENCIL_BUFFER_BIT);
	glDisable(GL_BLEND);
	glEnable(GL_DEPTH_TEST);
	glDisable(GL_STENCIL_TEST);

	mat4 V = sceneCamera.View();
	mat4 P = sceneCamera.Projection();

	litTexturedOpaque.bind();
	litTexturedOpaque.setUniform("tex", 0);
	litTexturedOpaque.setUniform("shadowTex", 1);
	litTexturedOpaque.setUniform("lightVP", lightVP);
	litTexturedOpaque.setUniform("lightDir", mat3(V)*lightDir);

	litTexturedAlphaTest.bind();
	litTexturedAlphaTest.setUniform("tex", 0);
	litTexturedAlphaTest.setUniform("shadowTex", 1);
	litTexturedAlphaTest.setUniform("lightVP", lightVP);
	litTexturedAlphaTest.setUniform("lightDir", mat3(V)*lightDir);


	litTexturedOpaque.bind();
	litTexturedOpaque.setUniform("M", ground.modelMatrix);
	litTexturedOpaque.setUniform("MVP", P*V*ground.modelMatrix);
	litTexturedOpaque.setUniform("NM", transpose(inverse(mat3(V*ground.modelMatrix))));

	whiteTex.Bind(0);
	depthTexture.Bind(1);
	ground.Render();


	for (auto &kv:meshRenderers)
	{
		if (kv.second.tex)
		{
			kv.second.tex->Bind(0);
		}
		else
		{
			whiteTex.Bind(0);
		}
		if (dynamic_cast<Leaf*>(kv.first))
		{
			litTexturedAlphaTest.bind();
			litTexturedAlphaTest.setUniform("MVP", P*V*kv.second.modelMatrix);
			litTexturedAlphaTest.setUniform("NM", transpose(inverse(mat3(V*kv.second.modelMatrix))));
			litTexturedAlphaTest.setUniform("M", kv.second.modelMatrix);
			kv.second.Render();
		}
		else
		{
			litTexturedOpaque.bind();
			litTexturedOpaque.setUniform("MVP", P*V*kv.second.modelMatrix);
			litTexturedOpaque.setUniform("NM", transpose(inverse(mat3(V*kv.second.modelMatrix))));
			litTexturedOpaque.setUniform("M", kv.second.modelMatrix);
			kv.second.Render();
		}
	}

	drawGizmo();
}

void ProceduralTreeWindow::onUIUpdate()
{
	static float lastFPST = Time::time();
	static int fpsCount = 0;
	static float fps = 0;
	if (Time::time() - lastFPST > 1)
	{
		fps = fpsCount / (Time::time() - lastFPST);
		lastFPST = Time::time();
		fpsCount = 0;
	}
	++fpsCount;

	Window::onUIUpdate();

	updateTreeUI(&tree);
	drawAxis();
}

void ProceduralTreeWindow::onUpdate()
{
	Window::onUpdate();
	vec2 uv = vec2{ input.x(), height - input.y() } / vec2{ width, height };
	uv = uv*2.0f - 1.0f;

	editingCurve();

	if (input.getButton(0) && currentEditControlPointIdx == -1)
	{
		auto a = sceneCamera.EulerAngles();
		a += vec3(input.deltaY(), -input.deltaX(), 0)*0.005f;
		a.x = clamp(a.x, -pi<float>()*0.5f, pi<float>()*0.5f);
		sceneCamera.EulerAngles(a);
	}
	if (input.getButton(2))
	{
		if (!input.Shift())
		{
			float d = sceneCamera.Distance();
			d *= pow(1.01, input.deltaY()*0.1);
			sceneCamera.Distance(d);
		}
		else
		{
			auto p = sceneCamera.Position();
			p += vec3(0, input.deltaY()*sceneCamera.Distance(), 0)*0.001f;
			sceneCamera.Position(p);
		}
	}
}

void ProceduralTreeWindow::drawGizmo()
{
	unlitTexturedPrgram.bind();
	mat4 V = sceneCamera.View();
	mat4 P = sceneCamera.Projection();

	/*
	auto M = glm::translate(glm::mat4(1), glm::vec3( 0, 0, sin(Time::time())+1));
	unlitTexturedPrgram.setUniform("MVP", P*V*M);
	unlitTexturedPrgram.setUniform("tex", 0);
	axisTex.Bind(0);

	axis.Render();
	*/

	if (trunkCurve)
	{
		glDepthMask(GL_FALSE);
		glEnable(GL_BLEND);
		unlitColorProgram.bind();
		unlitColorProgram.setUniform("MVP", P*V*trunkCurveRenderer.modelMatrix);

		glDepthFunc(GL_GEQUAL);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		glEnable(GL_LINE_SMOOTH);
		unlitColorProgram.setUniform("color", vec4(0, 0, 1, 0.2));
		glLineWidth(3);
		trunkCurveRenderer.Render(GL_LINE_STRIP);

		glLineWidth(1);
		unlitColorProgram.setUniform("color", vec4(1, 0, 0, 0.2));
		trunkCurveControlTangentRenderer.Render(GL_LINES);

		glPointSize(5);
		unlitColorProgram.setUniform("color", vec4(0, 1, 0, 0.2));
		trunkCurveControlPointRenderer.Render(GL_POINTS);


		glDepthFunc(GL_LESS);
		glLineWidth(3);
		unlitColorProgram.setUniform("color", vec4(0, 0, 1, 1));
		trunkCurveRenderer.Render(GL_LINE_STRIP);

		glLineWidth(1);
		unlitColorProgram.setUniform("color", vec4(1, 0, 0, 1));
		trunkCurveControlTangentRenderer.Render(GL_LINES);

		glPointSize(5);
		unlitColorProgram.setUniform("color", vec4(0, 1, 0, 1));
		trunkCurveControlPointRenderer.Render(GL_POINTS);

		glDepthMask(GL_TRUE);
		glDisable(GL_BLEND);
	}
}

void ProceduralTreeWindow::onResize(int w, int h)
{
	Window::onResize(w,h);
	sceneCamera.ViewportSize({ w,h });
	glViewport(0, 0, w, h);
}

void ProceduralTreeWindow::drawAxis()
{
	//draw axis
	ImGui::SetNextWindowBgAlpha(0);
	ImGui::SetNextWindowPos(ImVec2( width - 300,height - 300 ));
	ImGui::SetNextWindowSize( ImVec2(300,300 ));
	ImGui::Begin("Axis",0,ImGuiWindowFlags_NoDecoration| ImGuiWindowFlags_NoInputs);
	auto drawList = ImGui::GetWindowDrawList();
	auto pos = ImGui::GetWindowPos();
	auto size = ImGui::GetWindowSize();
	auto center = vec2{ pos.x+ size.x*0.5,pos.y + size.y*0.5 };

	float axisMaxLength = min(size.x, size.y)*0.5 - 2*ImGui::GetFontSize();
	float axisTextOffset = axisMaxLength + ImGui::GetFontSize()*0.5;

	mat4 V = mat4(mat3(sceneCamera.View()));
	{
		vec4 p1 = V*vec4(axisMaxLength, 0, 0, 1);
		vec4 p2 = V*vec4(axisTextOffset, 0, 0, 1);
		p1.y = -p1.y;
		p2.y = -p2.y;
		drawList->AddText(ImVec2(center.x + p2.x - ImGui::GetFontSize()*0.25, center.y + p2.y - ImGui::GetFontSize()*0.5), ImColor(1.0f, 0.0f, 0.0f, 1.0f), "X");
		drawList->AddLine(ImVec2(center.x, center.y), ImVec2(center.x + p1.x, center.y + p1.y), ImColor(1.0f, 0.0f, 0.0f, 1.0f), 4);
	}

	{
		vec4 p1 = V*vec4(0, axisMaxLength, 0, 1);
		vec4 p2 = V*vec4( 0,axisTextOffset, 0, 1);
		p1.y = -p1.y;
		p2.y = -p2.y;
		drawList->AddText(ImVec2(center.x + p2.x - ImGui::GetFontSize()*0.25, center.y + p2.y - ImGui::GetFontSize()*0.5), ImColor( 0.0f, 1.0f,0.0f, 1.0f), "Y");
		drawList->AddLine(ImVec2(center.x, center.y), ImVec2(center.x + p1.x, center.y + p1.y), ImColor(0.0f, 1.0f, 0.0f, 1.0f), 4);
	}

	{
		vec4 p1 = V*vec4(0, 0, axisMaxLength, 1);
		vec4 p2 = V*vec4(0, 0, axisTextOffset, 1);
		p1.y = -p1.y;
		p2.y = -p2.y;
		drawList->AddText(ImVec2(center.x + p2.x - ImGui::GetFontSize()*0.25, center.y + p2.y - ImGui::GetFontSize()*0.5), ImColor(0.0f, 0.0f, 1.0f, 1.0f), "Z");
		drawList->AddLine(ImVec2(center.x, center.y), ImVec2(center.x + p1.x, center.y + p1.y), ImColor(0.0f, 0.0f, 1.0f, 1.0f), 4);
	}
	ImGui::End();
}

void ProceduralTreeWindow::onTreeDataChanged(ProceduralTreeData * treeData)
{
	meshRenderers[treeData].UpdateMeshData(treeData->getMesh().position, treeData->getMesh().normal, treeData->getMesh().uv, treeData->getMesh().indices);
}

void ProceduralTreeWindow::onRemoveFromTree(ProceduralTreeData * treeData)
{
	meshRenderers.erase(treeData);
}

void ProceduralTreeWindow::onCurveUpdate(BezierCurve * curve)
{
	updateTrunkCurveGizmo();
}

#pragma once
#include "VertexArray.h"
#include "Buffer.h"
#include "Mesh.h"
#include "texture2D.h"
#include <memory>

class MeshRenderer
{
	VertexArray VAO;
	Buffer VBO;
	Buffer EBO;
	int primitiveCount;
	bool drawArrays=true;
public:
	MeshRenderer();
	~MeshRenderer();

	glm::mat4 modelMatrix=glm::mat4(1);
	std::shared_ptr<Texture2D> tex;

	void CreateFromMesh(const Mesh &mesh);
	void UpdateMeshData(std::vector<glm::vec3> positions, std::vector<glm::vec3> normals, std::vector<glm::vec2> uvs, std::vector<unsigned int> indices = {});

	void Render(GLenum drawMode=GL_TRIANGLES);
};


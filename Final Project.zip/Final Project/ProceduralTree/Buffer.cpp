#include "Buffer.h"



Buffer::~Buffer()
{
	Destroy();
}

Buffer::operator bool()
{
	return id;
}

void Buffer::Create(GLenum target, int s/*=1024*/, void *data /*= 0*/, GLenum hint /*= GL_STATIC_DRAW*/)
{
	this->size = s;
	this->target = target;
	this->hint = hint;
	glGenBuffers(1, &id);
	glBindBuffer(target, id);
	glBufferData(target, size, data, hint);
}

void Buffer::Bind()
{
	assert(id != 0 && "Buffer not initialized!");
	glBindBuffer(target, id);
}

void Buffer::BindBufferBase(int bindIdx)
{
	glBindBufferBase(target, bindIdx, id);
}

void Buffer::Unbind()
{
	glBindBuffer(target, 0);
}

void Buffer::Resize(int size)
{
	assert(id != 0 && "Buffer not initialized!");
	if (this->size < size)
	{
		this->size = size;
		glBindBuffer(target, id);
		glBufferData(target, size, 0, hint);
	}
}

void Buffer::FillData(int offset, void *data, int size)
{
	assert(id != 0 && "Buffer not initialized!");
	glNamedBufferSubData(id, offset, size, data);
}

void Buffer::ReadData(int offset, int size, void * data)
{
	glGetNamedBufferSubData(id, offset, size, data);
}

void Buffer::Destroy()
{
	Unbind();
	glDeleteBuffers(1, &id);
	size = 0;
	id = 0;
	target = 0;
	hint = 0;
}

#pragma once
#include <glfw/glfw3.h>
#include <xutility>

class Input
{
	bool oldKeyState[1024];
	bool keyState[1024];
	bool oldButtonState[16];
	bool buttonState[16];

	bool shift;
	bool ctrl;
	bool alt;

	float lastX;
	float lastY;
	float _x;
	float _y;
public:
	Input();
	void onKey(int key,int scancode,int action,int mod);
	void onMouseButton(int button, int action, int mod);
	void onMouseMove(float x, float y);

	bool getButton(int button);
	bool getButtonDown(int button);
	bool getButtonUp(int button);
	bool getKey(int key);
	bool getKeyDown(int key);
	bool getKeyUp(int key);

	bool Shift();
	bool Ctrl();
	bool Alt();

	void endFrame();
	float x() const;
	float y() const;
	float deltaX() const;
	float deltaY() const;
};

#include "Shader.h"
#include <fstream>
#include <string>
using namespace std;


const char * Shader::getLog() const
{
	return log.c_str();
}

Shader::operator bool()
{
	return id;
}

Shader::Shader()
{
}


Shader::~Shader()
{
	destroy();
}

bool Shader::loadFromSrc(GLenum shaderType, const char *src)
{
	id=glCreateShader(shaderType);
	glShaderSource(id, 1, &src, 0);
	glCompileShader(id);
	int status = GL_TRUE;
	
	glGetShaderiv(id, GL_COMPILE_STATUS, &status);
	if (!status)
	{
		int logLen = 0;
		glGetShaderiv(id, GL_INFO_LOG_LENGTH, &logLen);
		log.resize(logLen + 1);
		glGetShaderInfoLog(id, logLen, 0, &log[0]);
		destroy();
	}
	return id;
}

bool Shader::loadFromFile(GLenum shaderType, const char *path)
{
	ifstream ifs(path);
	if (ifs)
	{
		string src;
		string line;
		while (getline(ifs,line))
		{
			src = src + "\n" + line;
		}
		ifs.close();
		return loadFromSrc(shaderType, src.c_str());
	}
	return false;
}

void Shader::destroy()
{
	if (id)
	{
		glDeleteShader(id);
		id = 0;
	}
}

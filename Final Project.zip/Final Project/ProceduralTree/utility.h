#pragma once
#include <gl/glew.h>
#include <imgui/imgui.h>
#include <stb_image.h>
#include <vector>

struct ImguiIdHelper
{
	ImguiIdHelper(long long id)
	{
		ImGui::PushID(id);
	}
	~ImguiIdHelper()
	{
		ImGui::PopID();
	}
};

struct ViewPortGuard
{
	int oldViewport[4];
	ViewPortGuard()
	{
		glGetIntegerv(GL_VIEWPORT, oldViewport);
	}
	~ViewPortGuard()
	{
		glViewport(oldViewport[0], oldViewport[1], oldViewport[2], oldViewport[3]);
	}
};

struct BlendStateGuard
{
	int enabled;
	int sfactor;
	int dfactor;
	BlendStateGuard()
	{
		glGetIntegerv(GL_BLEND, &enabled);
		glGetIntegerv(GL_BLEND_SRC_ALPHA, &sfactor);
		glGetIntegerv(GL_BLEND_DST_ALPHA, &dfactor);

	}
	~BlendStateGuard()
	{
		if (enabled)
		{
			glEnable(GL_BLEND);
		}
		else
		{
			glDisable(GL_BLEND);
		}
		glBlendFunc(sfactor, dfactor);
	}
};


struct BufferMaskGuard
{
	int colorMask[4];
	int depthMask;
	BufferMaskGuard()
	{
		glGetIntegerv(GL_COLOR_WRITEMASK, colorMask);
		glGetIntegerv(GL_DEPTH_WRITEMASK, &depthMask);

	}
	~BufferMaskGuard()
	{
		glColorMask(colorMask[0], colorMask[1], colorMask[2], colorMask[3]);
		glDepthMask(depthMask);
	}
};


static void ClearGLError()
{
	while (glGetError());
}

static void PrintGLError()
{
	while (true)
	{
		auto error = glGetError();
		if (!error)
		{
			break;
		}
		printf("GLError:%d\n", error);
	}
}

std::vector<unsigned char> loadTexture(const char *path, int &w, int &h);
